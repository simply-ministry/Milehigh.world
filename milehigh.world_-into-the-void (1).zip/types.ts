export interface Character {
  name: string;
  title: string;
  archetype: string;
  description: string;
  usd: string;
  imageUrl: string;
}

export interface FileTreeNode {
  name: string;
  type: 'folder' | 'file';
  children?: FileTreeNode[];
  description?: string;
  path?: string;
}

export interface NarrativeElement {
  element: string;
  description: string;
  purpose: string;
}

export interface WorldFaction {
  setting: string;
  focus: string;
  implication: string;
}

export interface CharacterRole {
  character: string;
  archetype: string;
  role: string;
}

export interface TranscriptionEntry {
  speaker: 'User' | 'Sky.ix' | string;
  text: string;
  tone?: string;
}

export interface KeyConcept {
    name: string;
    description: string;
}

// Fix: Added DigitalMotif interface to type the corresponding constant.
export interface DigitalMotif {
  name: string;
  binary: string;
}

export interface Reputation {
  [key: string]: number;
}

export interface MissionGenerationResponse {
  mission: string;
  objective: string;
  consequences: string;
  reputationImpact: {
    faction: string;
    change: number;
  }[];
}

export interface VoiceProfile {
  characterName: string;
  voiceName: string;
  systemInstruction: string;
}

import React, { useState, useCallback } from 'react';
import { Header } from './components/Header';
import { Card } from './components/Card';
import { FileTree } from './components/FileTree';
import { CharacterCard } from './components/CharacterCard';
import { MissionGenerator } from './components/MissionGenerator';
import { LiveConversation } from './components/LiveConversation';
import { CharacterDialogueGenerator } from './components/CharacterDialogueGenerator';
import { LoreQuery } from './components/LoreQuery';
import { IntelLogger } from './components/IntelLogger';
import { ReputationTracker } from './components/ReputationTracker';
import { VoiceConfigurationViewer } from './components/VoiceConfigurationViewer';
import { ImageGenerator } from './components/ImageGenerator';
import { WorldBuildingChart } from './components/WorldBuildingChart';
import { CharacterDynamicsChart } from './components/CharacterDynamicsChart';
import { 
  FILE_STRUCTURE, 
  CHARACTERS, 
  PROJECT_OVERVIEW, 
  DIGITAL_MOTIF, 
  PYTHON_SCRIPTS, 
  CSHARP_OVERVIEW,
  NARRATIVE_BLUEPRINT_TABLE,
  CORE_EMOTIONAL_ARCS,
  NARRATIVE_VIGNETTES,
  KEY_CONCEPTS,
  INITIAL_VOICE_PROFILES,
  CORE_GAMEPLAY_LOOP,
  COMBAT_SYSTEM,
  EXPLORATION_TRAVERSAL,
  ART_STYLE
} from './constants';
import { INITIAL_LORE_CONTEXT } from './services/geminiService';
import type { Character, Reputation, VoiceProfile, MissionGenerationResponse } from './types';

const App: React.FC = () => {
  const voiceProfiles = INITIAL_VOICE_PROFILES;
  const [userIntelLog, setUserIntelLog] = useState<string>('');
  const [reputation, setReputation] = useState<Reputation>({
    'Ɲōvəmîŋāđ Alliance': 50,
    "Cirrus's Trust": 50,
  });
  const [currentMission, setCurrentMission] = useState<MissionGenerationResponse | null>(null);

  const addIntelToLog = useCallback((newIntel: string) => {
    const timestamp = new Date().toISOString();
    const formattedIntel = `\n\n**--- INTEL LOG UPDATE [${timestamp}] ---**\n${newIntel}\n**--- END OF UPDATE ---**`;
    setUserIntelLog(prevLog => prevLog + formattedIntel);
  }, []);

  const updateReputation = useCallback((faction: string, change: number) => {
    setReputation(prevRep => {
      const newScore = Math.max(0, Math.min(100, (prevRep[faction] || 50) + change));
      return { ...prevRep, [faction]: newScore };
    });
  }, []);
  
  const fullLoreContext = `${INITIAL_LORE_CONTEXT}
  
  **--- CURRENT CAMPAIGN STATE ---**
  **Reputation Scores:**
  ${Object.entries(reputation).map(([faction, score]) => `- ${faction}: ${score}/100`).join('\n')}
  
  **Logged Intel:**
  ${userIntelLog || "No new intel logged."}
  
  ${currentMission ? `**--- ACTIVE MISSION BRIEFING ---**
  **Mission:** ${currentMission.mission}
  **Objective:** ${currentMission.objective}
  **Risks:** ${currentMission.consequences}
  **Reputation Impact:** ${currentMission.reputationImpact.map(i => `${i.faction}: ${i.change > 0 ? '+' : ''}${i.change}`).join(', ')}
  ` : "**--- NO ACTIVE MISSION ---**"}
  **--- END OF CURRENT STATE ---**
  `;

  return (
    <div className="min-h-screen bg-black/60 text-gray-300">
      <div className="container mx-auto p-4 md:p-8">
        <Header />
        
        <div>
          <main className="mt-8 grid grid-cols-1 lg:grid-cols-3 gap-8">
            
            {/* Left Column */}
            <div className="lg:col-span-2 space-y-8">
              <Card title="Project Overview">
                <p className="text-gray-400 whitespace-pre-line">{PROJECT_OVERVIEW}</p>
              </Card>

              <Card title="Core Gameplay Loop">
                <p className="text-gray-400 whitespace-pre-line">{CORE_GAMEPLAY_LOOP}</p>
              </Card>

              <Card title="Combat System">
                <div className="space-y-6">
                  {COMBAT_SYSTEM.map(system => (
                    <div key={system.name}>
                      <h3 className="text-sm font-semibold text-gray-300 uppercase tracking-wider">{system.name}</h3>
                      <p className="text-gray-400 text-sm mt-1 pl-2 border-l-2 border-gray-700 whitespace-pre-line">{system.description}</p>
                    </div>
                  ))}
                </div>
              </Card>

              <Card title="Exploration & Traversal">
                <div className="space-y-6">
                  {EXPLORATION_TRAVERSAL.map(system => (
                    <div key={system.name}>
                      <h3 className="text-sm font-semibold text-gray-300 uppercase tracking-wider">{system.name}</h3>
                      <p className="text-gray-400 text-sm mt-1 pl-2 border-l-2 border-gray-700 whitespace-pre-line">{system.description}</p>
                    </div>
                  ))}
                </div>
              </Card>

              <Card title="Visual Style & Art Direction">
                  <p className="text-gray-400 whitespace-pre-line">{ART_STYLE}</p>
              </Card>
              
              <Card title="Concept Art Generator">
                <ImageGenerator />
              </Card>

              <Card title="Campaign Reputation">
                  <ReputationTracker reputation={reputation} />
              </Card>

              <Card title="Mission Generator">
                  <MissionGenerator 
                    loreContext={fullLoreContext} 
                    addIntelToLog={addIntelToLog}
                    updateReputation={updateReputation}
                    voiceProfiles={voiceProfiles}
                    currentMission={currentMission}
                    setCurrentMission={setCurrentMission}
                  />
              </Card>

              <Card title="Memory Log Input">
                  <IntelLogger addIntelToLog={addIntelToLog} />
              </Card>

              <Card title="Live Comms">
                  <LiveConversation 
                    loreContext={fullLoreContext} 
                    onNewIntel={addIntelToLog} 
                    voiceProfiles={voiceProfiles} 
                  />
              </Card>
              
              <Card title="Character Dialogue Scene">
                  <CharacterDialogueGenerator 
                    loreContext={fullLoreContext}
                    voiceProfiles={voiceProfiles}
                  />
              </Card>

              <Card title="Knowledge Base Terminal">
                  <LoreQuery 
                    loreContext={fullLoreContext} 
                    voiceProfiles={voiceProfiles}
                  />
              </Card>

              <Card title="Core Narrative Blueprint">
                <div className="overflow-x-auto">
                  <table className="w-full text-sm text-left text-gray-400">
                    <thead className="text-xs text-gray-300 uppercase bg-gray-800 font-sans">
                      <tr>
                        <th scope="col" className="px-4 py-3 tracking-wider">Element</th>
                        <th scope="col" className="px-4 py-3 tracking-wider">Description</th>
                        <th scope="col" className="px-4 py-3 tracking-wider">Narrative Purpose</th>
                      </tr>
                    </thead>
                    <tbody>
                      {NARRATIVE_BLUEPRINT_TABLE.map((item, index) => (
                        <tr key={index} className="border-b border-gray-800 hover:bg-gray-800/30">
                          <td className="px-4 py-3 font-semibold text-gray-200">{item.element}</td>
                          <td className="px-4 py-3">{item.description}</td>
                          <td className="px-4 py-3">{item.purpose}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </Card>

              <Card title="Key Concepts">
                <div className="space-y-6">
                  {KEY_CONCEPTS.map(concept => (
                    <div key={concept.name}>
                      <h3 className="text-sm font-semibold text-gray-300 uppercase tracking-wider">{concept.name}</h3>
                      <p className="text-gray-400 text-sm mt-1 pl-2 border-l-2 border-gray-700">{concept.description}</p>
                    </div>
                  ))}
                </div>
              </Card>

              <Card title="World-Building & Factions">
                <WorldBuildingChart />
              </Card>

              <Card title="Character Dynamics & Roles">
                <CharacterDynamicsChart />
              </Card>

              <Card title="Core Emotional Arcs">
                <p className="text-gray-400 whitespace-pre-line">{CORE_EMOTIONAL_ARCS}</p>
              </Card>
              
              <Card title="Narrative Vignettes">
                 <p className="text-gray-400 whitespace-pre-line">{NARRATIVE_VIGNETTES}</p>
              </Card>

              <Card title="The Nōvəmînāđ (Playable Characters)">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      {CHARACTERS.map((char: Character, index) => (
                          <CharacterCard 
                            key={char.name} 
                            character={char} 
                            index={index} 
                            loreContext={fullLoreContext}
                          />
                      ))}
                  </div>
              </Card>
            </div>
            
            {/* Right Column */}
            <div className="lg:col-span-1 space-y-8">
              <Card title="Repository Structure">
                <div className="bg-gray-950/80 p-4 overflow-x-auto rounded">
                  <FileTree node={FILE_STRUCTURE} />
                </div>
              </Card>

              <Card title="Voice System Diagnostics">
                <VoiceConfigurationViewer 
                  voiceProfiles={voiceProfiles}
                />
              </Card>

              <Card title="The Digital Motif">
                  <p className="text-gray-400 mb-4">The project reinforces its digital, cyberpunk roots through a recurring binary motif.</p>
                  {DIGITAL_MOTIF.map(item => (
                      <div key={item.name} className="mb-3">
                          <h3 className="text-cyan-400 font-mono text-sm uppercase">{item.name}</h3>
                          <p className="text-gray-400 font-mono text-sm break-words bg-black p-2 mt-1 rounded">{item.binary}</p>
                      </div>
                  ))}
              </Card>

              <Card title="Python Scripts Overview">
                  <p className="text-gray-400 whitespace-pre-line">{PYTHON_SCRIPTS}</p>
              </Card>

              <Card title="C# Codebase Overview">
                   <p className="text-gray-400 whitespace-pre-line">{CSHARP_OVERVIEW}</p>
              </Card>
            </div>
          </main>
        </div>
      </div>
    </div>
  );
};

export default App;
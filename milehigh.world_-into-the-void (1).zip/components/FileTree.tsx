

import React from 'react';
import type { FileTreeNode } from '../types';
import { FolderIcon, FileIcon } from '../constants';

interface FileTreeProps {
  node: FileTreeNode;
  level?: number;
}

export const FileTree: React.FC<FileTreeProps> = ({ node, level = 0 }) => {
  const isFolder = node.type === 'folder';
  const indent = level * 20;

  return (
    <div>
      <div className="flex items-center text-gray-300" style={{ paddingLeft: `${indent}px` }}>
        {isFolder ? <FolderIcon className="text-cyan-400"/> : <FileIcon className="text-gray-400"/>}
        <span className="font-mono text-sm">{node.name}</span>
        {node.description && <span className="ml-4 text-xs text-gray-500 italic hidden sm:inline"> - {node.description}</span>}
      </div>
      {isFolder && node.children && (
        <div className="border-l border-gray-700 ml-2.5">
          {node.children.map((child, index) => (
            <FileTree key={index} node={child} level={level + 1} />
          ))}
        </div>
      )}
    </div>
  );
};
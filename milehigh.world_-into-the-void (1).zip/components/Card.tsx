import React from 'react';

interface CardProps {
  title: string;
  children: React.ReactNode;
  className?: string;
}

export const Card: React.FC<CardProps> = ({ title, children, className = '' }) => {
  return (
    <div className={`bg-gray-950/70 border border-cyan-500/30 rounded-lg overflow-hidden shadow-lg shadow-cyan-500/10 transition-transform duration-300 hover:scale-[1.02] backdrop-blur-sm ${className}`}>
      <h2 className="text-base font-bold text-white bg-cyan-600/80 p-3 uppercase tracking-wider">{title}</h2>
      <div className="p-6">
        {children}
      </div>
    </div>
  );
};
import React, { useState, useRef, useCallback, useEffect } from 'react';
import { generateGroupConversationScript, generateSpeech } from '../services/geminiService';
import { decode, decodeAudioData } from '../utils/audio';
import { sanitizeInput } from '../utils/textUtils';
import { SpeakerIcon, StopIcon } from '../constants';
import type { TranscriptionEntry, VoiceProfile } from '../types';

interface LiveConversationProps {
  loreContext: string;
  onNewIntel: (intel: string) => void;
  voiceProfiles: VoiceProfile[];
}

export const LiveConversation: React.FC<LiveConversationProps> = ({ loreContext, onNewIntel, voiceProfiles }) => {
    const [allCharacters] = useState(() => voiceProfiles.map(p => p.characterName));
    const [selectedCharacters, setSelectedCharacters] = useState<string[]>(() => {
        const defaultSelection = ['Sky.ix', 'Aeron', 'Zaia'];
        const availableNames = voiceProfiles.map(p => p.characterName);
        return defaultSelection.filter(name => availableNames.includes(name));
    });
    const [topic, setTopic] = useState('');
    const [isGenerating, setIsGenerating] = useState(false);
    const [isPlaying, setIsPlaying] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [dialogue, setDialogue] = useState<TranscriptionEntry[]>([]);
    const [currentLineIndex, setCurrentLineIndex] = useState<number | null>(null);
    const [isCharacterListOpen, setIsCharacterListOpen] = useState(false);
    
    const audioContextRef = useRef<AudioContext | null>(null);
    const audioSourceRef = useRef<AudioBufferSourceNode | null>(null);
    const stopPlaybackRef = useRef(false);

    const stopAudio = useCallback(() => {
        if (audioSourceRef.current) {
            try {
                audioSourceRef.current.stop();
                audioSourceRef.current.disconnect();
            } catch (e) {
                console.warn("Could not stop audio source:", e);
            }
            audioSourceRef.current = null;
        }
        if (audioContextRef.current && audioContextRef.current.state !== 'closed') {
            audioContextRef.current.close().catch(console.error);
            audioContextRef.current = null;
        }
    }, []);

    const handleStop = useCallback(() => {
        stopPlaybackRef.current = true;
        stopAudio();
        setIsGenerating(false);
        setIsPlaying(false);
        setCurrentLineIndex(null);
    }, [stopAudio]);

    const playAudio = useCallback((base64Audio: string) => {
        return new Promise<void>(async (resolve, reject) => {
            if (stopPlaybackRef.current) return resolve();
            
            try {
                if (!audioContextRef.current || audioContextRef.current.state === 'closed') {
                    audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
                }
                const ctx = audioContextRef.current;
                const audioBuffer = await decodeAudioData(decode(base64Audio), ctx, 24000, 1);
                
                if (stopPlaybackRef.current) return resolve();
                
                const source = ctx.createBufferSource();
                audioSourceRef.current = source;
                source.buffer = audioBuffer;
                source.connect(ctx.destination);
                source.onended = () => {
                    if (audioSourceRef.current === source) {
                        audioSourceRef.current = null;
                    }
                    resolve();
                };
                source.start();
            } catch(err) {
                reject(err);
            }
        });
    }, []);
    
    const playConversation = useCallback(async (script: TranscriptionEntry[], startIndex: number = 0) => {
        setIsPlaying(true);
        for (let i = startIndex; i < script.length; i++) {
            if (stopPlaybackRef.current) break;
            
            const entry = script[i];
            setCurrentLineIndex(i);

            const profile = voiceProfiles.find(p => p.characterName === entry.speaker);
            if (!profile) continue;

            try {
                const textForSpeech = entry.tone ? `(${entry.tone}) ${entry.text}` : entry.text;
                
                const base64Audio = await generateSpeech(
                    textForSpeech,
                    profile.voiceName
                );
                if (stopPlaybackRef.current) break;
                await playAudio(base64Audio);
                
                if (i < script.length - 1) {
                   await new Promise(resolve => setTimeout(resolve, 350));
                }

            } catch (err) {
                setError(err instanceof Error ? `Audio generation failed: ${err.message}` : 'An unknown audio error occurred.');
                break;
            }
        }
        handleStop();
    }, [voiceProfiles, playAudio, handleStop]);
    
    const handleGenerate = useCallback(async () => {
        if (selectedCharacters.length < 2) {
            setError("Please select at least two characters.");
            return;
        }
        setIsGenerating(true);
        setIsPlaying(false);
        setError(null);
        setDialogue([]);
        setCurrentLineIndex(null);
        stopPlaybackRef.current = false;
        
        try {
            const scriptText = await generateGroupConversationScript(loreContext, selectedCharacters, sanitizeInput(topic));
            const lines = scriptText.split('\n').filter(line => line.trim() !== '' && line.includes(':'));
            
            const parsedScript: TranscriptionEntry[] = lines.map(line => {
                const toneRegex = /^([^:]+):\s*\(([^)]+)\)\s*(.*)$/;
                const noToneRegex = /^([^:]+):\s*(.*)$/;
                
                const toneMatch = line.match(toneRegex);
                if (toneMatch) {
                    return {
                        speaker: toneMatch[1].trim(),
                        tone: toneMatch[2].trim(),
                        text: toneMatch[3].trim()
                    };
                }
                
                const noToneMatch = line.match(noToneRegex);
                if (noToneMatch) {
                    return {
                        speaker: noToneMatch[1].trim(),
                        text: noToneMatch[2].trim()
                    };
                }

                const parts = line.split(/:(.*)/s);
                return { speaker: parts[0].trim(), text: parts[1]?.trim() || '' };
            }).filter(entry => entry.text && allCharacters.includes(entry.speaker));

            if(parsedScript.length === 0) {
                throw new Error("The AI failed to generate a valid script. Please try again.");
            }

            setDialogue(parsedScript);
            setIsGenerating(false);
            onNewIntel(`Generated comms transcript:\n${parsedScript.map(d => `- ${d.speaker}: ${d.text}`).join('\n')}`);
            await playConversation(parsedScript);
        } catch(err) {
            setError(err instanceof Error ? err.message : 'An unknown error occurred.');
            setIsGenerating(false);
        }
    }, [selectedCharacters, topic, loreContext, onNewIntel, playConversation, allCharacters]);

    const handleTranscriptLineClick = useCallback(async (index: number) => {
        if (dialogue.length === 0 || isGenerating) {
            return;
        }
        handleStop();
        setTimeout(async () => {
            stopPlaybackRef.current = false;
            await playConversation(dialogue, index);
        }, 100);
    }, [dialogue, isGenerating, handleStop, playConversation]);

    useEffect(() => {
        return () => {
            stopPlaybackRef.current = true;
            stopAudio();
        };
    }, [stopAudio]);

    const handleCharacterSelection = (characterName: string) => {
        setSelectedCharacters(prev => 
            prev.includes(characterName) 
                ? prev.filter(c => c !== characterName) 
                : [...prev, characterName]
        );
    };

    const handleSelectAll = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.checked) {
            setSelectedCharacters(allCharacters);
        } else {
            setSelectedCharacters([]);
        }
    }

    const disableControls = isGenerating || isPlaying;

    return (
        <div className="flex flex-col items-center">
            <p className="text-gray-400 mb-4 text-center">
                Generate a conversation between members of the Ɲōvəmîŋāđ. The AI will create a unique, in-character script and play it back with their distinct voices.
            </p>

            <div className="w-full max-w-lg mb-4 space-y-4">
                <div className="relative">
                    <label className="block text-sm font-medium text-gray-400 mb-1 text-center">Select Characters ({selectedCharacters.length})</label>
                    <button onClick={() => setIsCharacterListOpen(o => !o)} disabled={disableControls} className="w-full bg-gray-700 border border-gray-600 text-gray-300 text-sm rounded-md focus:ring-cyan-500 focus:border-cyan-500 block p-2.5 disabled:opacity-50 text-left truncate">
                        {selectedCharacters.join(', ') || 'Select characters...'}
                    </button>
                    {isCharacterListOpen && (
                        <div className="absolute z-10 w-full mt-1 bg-gray-800 border border-gray-600 rounded-md shadow-lg max-h-60 overflow-y-auto">
                           <div className="p-2 border-b border-gray-600">
                                <label className="flex items-center space-x-2 px-2 text-gray-300">
                                    <input type="checkbox"
                                        checked={selectedCharacters.length === allCharacters.length}
                                        onChange={handleSelectAll}
                                        className="w-4 h-4 text-cyan-600 bg-gray-700 border-gray-600 rounded focus:ring-cyan-500"
                                    />
                                    <span>Select All</span>
                                </label>
                            </div>
                            {allCharacters.map(charName => (
                                <label key={charName} className="flex items-center space-x-2 p-2 hover:bg-gray-700 cursor-pointer text-gray-300">
                                    <input type="checkbox"
                                        value={charName}
                                        checked={selectedCharacters.includes(charName)}
                                        onChange={() => handleCharacterSelection(charName)}
                                        className="w-4 h-4 text-cyan-600 bg-gray-700 border-gray-600 rounded focus:ring-cyan-500"
                                    />
                                    <span>{charName}</span>
                                </label>
                            ))}
                        </div>
                    )}
                </div>
                <div>
                    <label htmlFor="topic-input" className="block text-sm font-medium text-gray-400 mb-1 text-center">Conversation Topic (Optional)</label>
                    <input
                        id="topic-input"
                        type="text"
                        value={topic}
                        onChange={e => setTopic(e.target.value)}
                        placeholder="e.g., The strange energy at the Nexus"
                        disabled={disableControls}
                        className="bg-gray-700 border border-gray-600 text-gray-300 text-sm rounded-md focus:ring-cyan-500 focus:border-cyan-500 block w-full p-2.5 disabled:opacity-50"
                    />
                </div>
            </div>

            <button
                onClick={disableControls ? handleStop : handleGenerate}
                disabled={isGenerating}
                className={`flex items-center justify-center gap-2 font-bold py-2 px-6 uppercase tracking-wider transition-colors focus:outline-none focus:ring-2 focus:ring-opacity-75 rounded-md ${
                    disableControls ? 'bg-gray-700 hover:bg-gray-600 focus:ring-gray-500' : 'bg-cyan-600 hover:bg-cyan-500 focus:ring-cyan-500'
                } ${isGenerating ? 'cursor-not-allowed animate-pulse' : ''}`}
                aria-label={disableControls ? "Stop playback" : "Generate conversation"}
            >
                {disableControls ? <StopIcon className="h-5 w-5"/> : <SpeakerIcon className="h-5 w-5"/>}
                <span>{isGenerating ? 'Generating...' : isPlaying ? 'Stop Playback' : 'Generate Conversation'}</span>
            </button>

            {error && (
                 <div className="mt-4 w-full bg-red-900/50 border border-red-700 text-red-300 px-4 py-3 text-center rounded">
                    <p><strong>Error:</strong> {error}</p>
                 </div>
            )}
            
            <div className="mt-6 w-full bg-black/50 border border-gray-700 p-4 min-h-[200px] rounded-md">
                <h3 className="text-base font-semibold text-gray-300 uppercase tracking-wider mb-2">Comms Transcript</h3>
                <div className="space-y-3 text-sm font-mono">
                    {dialogue.length > 0 ? (
                        dialogue.map((entry, index) => {
                            const isSpeaking = index === currentLineIndex;
                            const profile = voiceProfiles.find(p => p.characterName === entry.speaker);
                            const borderColor = profile ? (voiceProfiles.indexOf(profile) % 2 === 0 ? 'border-cyan-400' : 'border-gray-500') : 'border-gray-600';
                            
                            return (
                                <div 
                                    key={index} 
                                    onClick={() => handleTranscriptLineClick(index)}
                                    className={`border-l-4 py-1 pl-3 rounded transition-colors duration-300 hover:bg-gray-800/50 cursor-pointer ${isSpeaking ? 'bg-gray-900/50' : ''} ${borderColor}`}>
                                    <span className={`font-bold ${borderColor === 'border-cyan-400' ? 'text-cyan-400' : 'text-gray-400'}`}>{entry.speaker}: </span>
                                    {entry.tone && <span className="text-gray-500 italic">({entry.tone}) </span>}
                                    <span className="text-gray-300 whitespace-pre-wrap">{entry.text}</span>
                                    {isSpeaking && <span className="ml-2 text-xs text-gray-500 animate-pulse">speaking...</span>}
                                </div>
                            );
                        })
                    ) : (
                         <p className="text-gray-500 italic">
                            {isGenerating ? 'Generating script...' : 'Transcript will appear here...'}
                        </p>
                    )}
                </div>
            </div>
        </div>
    );
};

import React from 'react';
import type { VoiceProfile } from '../types';

interface VoiceConfigurationViewerProps {
  voiceProfiles: VoiceProfile[];
}

export const VoiceConfigurationViewer: React.FC<VoiceConfigurationViewerProps> = ({ voiceProfiles }) => {
    return (
        <div className="overflow-x-auto">
            <p className="text-gray-400 mb-4 text-sm">
                This table reflects the single source of truth for all character voice and persona configurations.
            </p>
            <table className="w-full text-sm text-left text-gray-400">
                <thead className="text-xs text-gray-300 uppercase bg-gray-800 font-sans">
                    <tr>
                        <th scope="col" className="px-4 py-3 tracking-wider">Character</th>
                        <th scope="col" className="px-4 py-3 tracking-wider">Voice Model</th>
                        <th scope="col" className="px-4 py-3 tracking-wider">Persona Snippet</th>
                    </tr>
                </thead>
                <tbody>
                    {voiceProfiles.map((profile) => (
                        <tr key={profile.characterName} className="border-b border-gray-800 hover:bg-gray-800/30">
                            <td className="px-4 py-3 font-semibold text-gray-200 align-middle">{profile.characterName}</td>
                            <td className="px-4 py-3 font-mono text-gray-400 align-middle">{profile.voiceName}</td>
                            <td className="px-4 py-3 text-xs italic align-middle">"{profile.systemInstruction.split('.')[0]}."</td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};
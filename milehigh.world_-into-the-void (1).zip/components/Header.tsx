

import React from 'react';

export const Header: React.FC = () => {
    return (
        <header className="text-center py-6 border-b border-gray-700 mb-12">
            <h1 className="text-4xl md:text-5xl font-black text-white tracking-widest uppercase">
                MILEHIGH.WORLD
            </h1>
            <p className="text-gray-400 mt-2 text-lg md:text-xl uppercase tracking-wider">Into the Void: Repository Explorer</p>
        </header>
    );
};
import React, { useEffect, useRef, useState, useMemo } from 'react';
import { WORLD_BUILDING_TABLE } from '../constants';
import type { WorldFaction } from '../types';

const worldBuildingData: { [key: string]: number[] } = {
    'ŁĪƝĈ':             [3, 4, 5, 3, 2], // Combat, Exploration, Technology, Social/Political, Mystical/Lore
    'ÅẒ̌ŪŘẸ ĤĒĪĜĤṬ§':   [2, 2, 2, 5, 1],
    'ÆṬĤŸŁĞÅŘÐ':        [5, 5, 1, 2, 2],
    'ƁÅČ̣ĤÎŘØN̈':         [2, 3, 1, 1, 5],
    'Hydraustis Palare':  [2, 5, 1, 1, 3],
    'ŤĤÊ VØĪĐ':          [4, 2, 3, 1, 5],
};
const chartLabels = ['Combat', 'Exploration', 'Technology', 'Social/Political', 'Mystical/Lore'];

export const WorldBuildingChart: React.FC = () => {
    const chartRef = useRef<HTMLCanvasElement>(null);
    const chartInstanceRef = useRef<any>(null); // Chart.js instance
    const [selectedSetting, setSelectedSetting] = useState<string>(WORLD_BUILDING_TABLE[0].setting);

    const selectedFaction = useMemo(() => {
        return WORLD_BUILDING_TABLE.find(f => f.setting === selectedSetting);
    }, [selectedSetting]);

    useEffect(() => {
        if (!chartRef.current || typeof (window as any).Chart === 'undefined') return;
        const ctx = chartRef.current.getContext('2d');
        if (!ctx) return;

        if (chartInstanceRef.current) {
            chartInstanceRef.current.destroy();
        }

        const data = worldBuildingData[selectedSetting] || [];

        chartInstanceRef.current = new (window as any).Chart(ctx, {
            type: 'radar',
            data: {
                labels: chartLabels,
                datasets: [{
                    label: selectedSetting,
                    data: data,
                    backgroundColor: 'rgba(34, 211, 238, 0.2)', // cyan-400
                    borderColor: 'rgb(34, 211, 238)',
                    pointBackgroundColor: 'rgb(34, 211, 238)',
                    pointBorderColor: '#fff',
                    pointHoverBackgroundColor: '#fff',
                    pointHoverBorderColor: 'rgb(34, 211, 238)',
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        callbacks: {
                            label: (context: any) => `${context.dataset.label}: ${context.formattedValue}`
                        }
                    }
                },
                scales: {
                    r: {
                        angleLines: { color: 'rgba(55, 65, 81, 0.5)' }, // gray-700
                        grid: { color: 'rgba(55, 65, 81, 0.5)' }, // gray-700
                        pointLabels: { 
                            color: 'rgba(209, 213, 219, 1)', // gray-300
                            font: {
                                family: 'monospace'
                            }
                        },
                        ticks: {
                            backdropColor: 'rgba(17, 24, 39, 1)', // gray-900
                            color: 'rgba(209, 213, 219, 1)',
                            stepSize: 1
                        },
                        min: 0,
                        max: 5
                    }
                }
            }
        });

        return () => {
            if (chartInstanceRef.current) {
                chartInstanceRef.current.destroy();
            }
        };
    }, [selectedSetting]);

    return (
        <div className="flex flex-col gap-4">
            <div>
                <label htmlFor="setting-select" className="sr-only">Select a setting</label>
                <select 
                    id="setting-select"
                    onChange={(e) => setSelectedSetting(e.target.value)} 
                    value={selectedSetting}
                    className="w-full bg-gray-700 border border-gray-600 text-gray-300 text-sm rounded-md focus:ring-cyan-500 focus:border-cyan-500 block p-2.5"
                >
                    {WORLD_BUILDING_TABLE.map((item: WorldFaction) => (
                        <option key={item.setting} value={item.setting}>{item.setting}</option>
                    ))}
                </select>
            </div>
            <div className="relative h-64 md:h-80">
                 <canvas ref={chartRef}></canvas>
            </div>
            {selectedFaction && (
                <div className="mt-4 space-y-3 text-sm border-t border-gray-700 pt-4">
                    <div>
                        <h4 className="font-bold text-gray-300 uppercase tracking-wider text-xs">Aesthetic/Conflict Focus:</h4>
                        <p className="text-gray-400">{selectedFaction.focus}</p>
                    </div>
                    <div>
                        <h4 className="font-bold text-gray-300 uppercase tracking-wider text-xs">Game Design Implication:</h4>
                        <p className="text-gray-400">{selectedFaction.implication}</p>
                    </div>
                </div>
            )}
        </div>
    );
};
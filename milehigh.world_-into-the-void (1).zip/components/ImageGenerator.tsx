import React, { useState, useCallback } from 'react';
import { generateImage } from '../services/geminiService';
import { sanitizeInput } from '../utils/textUtils';

export const ImageGenerator: React.FC = () => {
    const [prompt, setPrompt] = useState('');
    const [generatedImage, setGeneratedImage] = useState<string | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);

    const handleGenerateImage = useCallback(async (e: React.FormEvent) => {
        e.preventDefault();
        const sanitizedPrompt = sanitizeInput(prompt);
        if (!sanitizedPrompt) return;

        setIsLoading(true);
        setError(null);
        setGeneratedImage(null);

        try {
            const base64Image = await generateImage(sanitizedPrompt);
            setGeneratedImage(`data:image/jpeg;base64,${base64Image}`);
        } catch (err) {
            setError(err instanceof Error ? err.message : 'An unknown error occurred while generating the image.');
        } finally {
            setIsLoading(false);
        }
    }, [prompt]);
    
    const handleClear = () => {
        setPrompt('');
        setGeneratedImage(null);
        setError(null);
    }

    return (
        <div className="flex flex-col">
            <p className="text-gray-400 mb-4 text-center">
                Use the generator to create concept art for characters, environments, or scenes from the 'Into the Void' universe.
            </p>
            <form onSubmit={handleGenerateImage} className="flex flex-col gap-2">
                <textarea
                    value={prompt}
                    onChange={(e) => setPrompt(e.target.value)}
                    placeholder="e.g., A portrait of Aeron, the Skyborn Sentinel, guarding the gates of ÆṬĤŸŁĞÅŘÐ."
                    rows={3}
                    disabled={isLoading}
                    className="flex-grow bg-gray-800 border border-gray-700 text-gray-300 text-sm rounded-md focus:ring-cyan-500 focus:border-cyan-500 block w-full p-2.5 disabled:opacity-50"
                />
                <div className="flex flex-col sm:flex-row gap-2 justify-center">
                    <button
                        type="submit"
                        disabled={isLoading || !prompt.trim()}
                        className="bg-cyan-600 text-white font-bold py-2 px-6 uppercase tracking-wider rounded-md hover:bg-cyan-500 disabled:bg-gray-600 disabled:cursor-not-allowed transition-colors focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:ring-opacity-75"
                    >
                        {isLoading ? 'Generating...' : 'Generate Image'}
                    </button>
                    {(generatedImage || error) && (
                         <button
                            type="button"
                            onClick={handleClear}
                            disabled={isLoading}
                            className="bg-gray-600 text-white font-bold py-2 px-6 uppercase tracking-wider rounded-md hover:bg-gray-500 disabled:opacity-50 transition-colors"
                        >
                            Clear
                        </button>
                    )}
                </div>
            </form>

            {error && (
                 <div className="mt-4 w-full bg-red-900/50 border border-red-700 text-red-300 px-4 py-3 text-center rounded">
                    <p><strong>Error:</strong> {error}</p>
                 </div>
            )}
            
            <div className="mt-6 w-full">
                {isLoading && (
                    <div className="flex flex-col items-center justify-center p-8 bg-gray-950/80 border border-gray-800 border-dashed rounded-lg">
                        <svg className="animate-spin h-8 w-8 text-cyan-400" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                        </svg>
                        <p className="mt-4 text-gray-400 font-mono">Rendering visual data from the Verse...</p>
                    </div>
                )}
                {generatedImage && !isLoading && (
                    <div>
                        <img 
                            src={generatedImage} 
                            alt={sanitizeInput(prompt)} 
                            className="border-2 border-cyan-400/50 w-full rounded-lg"
                        />
                    </div>
                )}
            </div>
        </div>
    );
};
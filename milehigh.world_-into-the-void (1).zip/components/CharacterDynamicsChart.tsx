
import React, { useEffect, useRef } from 'react';
import { CHARACTER_DYNAMICS_TABLE } from '../constants';

const characterDynamicsData = {
    labels: CHARACTER_DYNAMICS_TABLE.map(d => d.character),
    datasets: [
        {
            label: 'Narrative Centrality',
            data: [5, 5, 3, 4, 4, 5, 3], // Sky.ix, Otis/X, Zaia, Aeron/Kane, Cirrus/Ingris, Ingris/Delilah, Nyxar
            backgroundColor: 'rgba(34, 211, 238, 0.8)', // cyan-400
            borderColor: 'rgba(34, 211, 238, 1)',
            borderWidth: 1,
        },
        {
            label: 'Combat Impact',
            data: [4, 4, 5, 5, 4, 5, 4],
            backgroundColor: 'rgba(107, 114, 128, 0.8)', // gray-500
            borderColor: 'rgba(107, 114, 128, 1)',
            borderWidth: 1,
        },
        {
            label: 'Emotional Core',
            data: [4, 5, 2, 5, 5, 5, 2],
            backgroundColor: 'rgba(243, 244, 246, 0.8)', // gray-100
            borderColor: 'rgba(243, 244, 246, 1)',
            borderWidth: 1,
        },
    ]
};

export const CharacterDynamicsChart: React.FC = () => {
    const chartRef = useRef<HTMLCanvasElement>(null);
    const chartInstanceRef = useRef<any>(null);

    useEffect(() => {
        if (!chartRef.current || typeof (window as any).Chart === 'undefined') return;
        const ctx = chartRef.current.getContext('2d');
        if (!ctx) return;

        if (chartInstanceRef.current) {
            chartInstanceRef.current.destroy();
        }

        chartInstanceRef.current = new (window as any).Chart(ctx, {
            type: 'bar',
            data: characterDynamicsData,
            options: {
                indexAxis: 'y',
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'top',
                        labels: {
                            color: 'rgba(209, 213, 219, 1)', // gray-300
                             font: {
                                family: 'monospace'
                            }
                        }
                    },
                    tooltip: {
                        mode: 'index',
                        intersect: false,
                    },
                    title: {
                        display: true,
                        text: 'Comparative Role Analysis (Rated 1-5)',
                        color: 'rgba(209, 213, 219, 1)',
                        font: {
                            size: 14,
                            family: 'monospace'
                        }
                    }
                },
                scales: {
                    x: {
                        stacked: false,
                        grid: {
                            color: 'rgba(55, 65, 81, 0.5)' // gray-700
                        },
                        ticks: {
                            color: 'rgba(156, 163, 175, 1)', // gray-400
                            stepSize: 1,
                        },
                        min: 0,
                        max: 5,
                    },
                    y: {
                        stacked: false,
                        grid: {
                            display: false
                        },
                        ticks: {
                            color: 'rgba(209, 213, 219, 1)', // gray-300
                        }
                    }
                }
            }
        });

        return () => {
            if (chartInstanceRef.current) {
                chartInstanceRef.current.destroy();
            }
        };
    }, []);

    return (
        <div className="flex flex-col">
            <p className="text-sm text-gray-400 mb-4 text-center">
                A visual breakdown of each key character dynamic's significance to the narrative, their impact on gameplay, and their emotional weight within the story.
            </p>
            <div className="relative h-96">
                <canvas ref={chartRef}></canvas>
            </div>
        </div>
    );
};

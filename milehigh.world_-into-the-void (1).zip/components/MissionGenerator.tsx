import React, { useState, useCallback, useRef, useEffect } from 'react';
import { generateMissionPrompt, generateSpeech } from '../services/geminiService';
import type { MissionGenerationResponse, VoiceProfile } from '../types';
import { decode, decodeAudioData } from '../utils/audio';
import { SpeakerIcon, StopIcon } from '../constants';

interface MissionGeneratorProps {
  loreContext: string;
  addIntelToLog: (intel: string) => void;
  updateReputation: (faction: string, change: number) => void;
  voiceProfiles: VoiceProfile[];
  currentMission: MissionGenerationResponse | null;
  setCurrentMission: (mission: MissionGenerationResponse | null) => void;
}

export const MissionGenerator: React.FC<MissionGeneratorProps> = ({ loreContext, addIntelToLog, updateReputation, voiceProfiles, currentMission, setCurrentMission }) => {
    const [isLoading, setIsLoading] = useState<boolean>(false);
    const [error, setError] = useState<string | null>(null);
    const [useThinkingMode, setUseThinkingMode] = useState<boolean>(false);
    const [isSpeaking, setIsSpeaking] = useState<boolean>(false);

    const audioContextRef = useRef<AudioContext | null>(null);
    const audioSourceRef = useRef<AudioBufferSourceNode | null>(null);

    const stopAudio = useCallback(() => {
        if (audioSourceRef.current) {
            audioSourceRef.current.stop();
            audioSourceRef.current.disconnect();
            audioSourceRef.current = null;
        }
        if (audioContextRef.current && audioContextRef.current.state !== 'closed') {
            audioContextRef.current.close().catch(console.error);
            audioContextRef.current = null;
        }
        setIsSpeaking(false);
    }, []);

    const handleListenToBriefing = useCallback(async () => {
        if (isSpeaking) {
            stopAudio();
            return;
        }
        if (!currentMission?.mission) return;

        setIsSpeaking(true);
        // Clear previous errors when attempting a new action
        setError(null);

        try {
            const base64Audio = await generateSpeech(currentMission.mission, 'Zephyr');

            if (!audioContextRef.current || audioContextRef.current.state === 'closed') {
                audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
            }
            const ctx = audioContextRef.current;
            const audioBuffer = await decodeAudioData(decode(base64Audio), ctx, 24000, 1);

            const source = ctx.createBufferSource();
            audioSourceRef.current = source;
            source.buffer = audioBuffer;
            source.connect(ctx.destination);
            source.onended = () => {
                if (audioSourceRef.current === source) {
                    stopAudio();
                }
            };
            source.start();
        } catch (err) {
            setError(err instanceof Error ? `Audio failed: ${err.message}` : 'An unknown audio error occurred.');
            stopAudio();
        }
    }, [currentMission, isSpeaking, stopAudio, voiceProfiles]);
    
    // Effect for cleaning up audio on component unmount
    useEffect(() => {
        return () => {
            stopAudio();
        };
    }, [stopAudio]);

    // Effect for stopping audio when the mission is acknowledged or declined
    useEffect(() => {
        if (!currentMission) {
            stopAudio();
        }
    }, [currentMission, stopAudio]);


    const handleGenerateMission = useCallback(async () => {
        setIsLoading(true);
        setError(null);
        setCurrentMission(null);
        try {
            const resultJson = await generateMissionPrompt(loreContext, useThinkingMode);
            const parsedResult: MissionGenerationResponse = JSON.parse(resultJson);
            setCurrentMission(parsedResult);
        } catch (err) {
            setError(err instanceof Error ? `Failed to generate or parse mission. ${err.message}` : 'An unknown error occurred.');
        } finally {
            setIsLoading(false);
        }
    }, [loreContext, useThinkingMode, setCurrentMission]);

    const handleAcknowledgeMission = useCallback(() => {
        if (!currentMission) return;

        const intelLog = `Mission Acknowledged:\n- **Objective:** ${currentMission.objective}\n- **Assessed Risks:** ${currentMission.consequences}`;
        addIntelToLog(intelLog);

        currentMission.reputationImpact.forEach(impact => {
            updateReputation(impact.faction, impact.change);
        });
        
        setCurrentMission(null);
    }, [currentMission, addIntelToLog, updateReputation, setCurrentMission]);

    const getReputationChangeColor = (change: number) => {
        if (change > 0) return 'text-green-400';
        if (change < 0) return 'text-red-400';
        return 'text-gray-400';
    };

    return (
        <div className="flex flex-col items-center">
            {!currentMission && (
                <>
                    <p className="text-gray-400 mb-4 text-center">Generate a unique mission with reputation consequences for the Ɲōvəmîŋāđ.</p>
                    <button
                        onClick={handleGenerateMission}
                        disabled={isLoading}
                        className="bg-cyan-600 text-white font-bold py-2 px-6 uppercase tracking-wider rounded-md hover:bg-cyan-500 disabled:bg-gray-600 disabled:cursor-not-allowed transition-colors focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:ring-opacity-75"
                    >
                        {isLoading ? 'Generating...' : 'Generate Mission'}
                    </button>
                    <div className="mt-3 flex items-center">
                        <input
                            type="checkbox"
                            id="thinking-mode-mission"
                            checked={useThinkingMode}
                            onChange={(e) => setUseThinkingMode(e.target.checked)}
                            disabled={isLoading}
                            className="w-4 h-4 text-cyan-600 bg-gray-700 border-gray-600 rounded focus:ring-cyan-500"
                        />
                        <label htmlFor="thinking-mode-mission" className="ml-2 text-sm font-medium text-gray-400">
                            Enable Deep Mission Planning (Slower)
                        </label>
                    </div>
                </>
            )}
            
            {error && (
                 <div className="mt-4 w-full bg-red-900/50 border border-red-700 text-red-300 px-4 py-3 text-center rounded">
                    <p><strong>Error:</strong> {error}</p>
                 </div>
            )}
            
            {currentMission && !isLoading && (
                <div className="mt-6 w-full bg-gray-950/80 border border-gray-700 p-4 rounded-md">
                    <div className="flex justify-between items-center mb-2">
                        <h3 className="text-base font-semibold text-cyan-400 uppercase tracking-wider">CLASSIFIED MISSION BRIEFING</h3>
                        <button
                            onClick={handleListenToBriefing}
                            disabled={isLoading}
                            className="flex items-center text-sm bg-gray-700 hover:bg-gray-600 px-2 py-1 rounded transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                            aria-label={isSpeaking ? "Stop briefing playback" : "Listen to briefing"}
                        >
                             {isSpeaking ? (
                                <>
                                    <StopIcon className="mr-1 h-4 w-4" /> Stop
                                </>
                            ) : (
                                <>
                                    <SpeakerIcon className="mr-1 h-4 w-4" /> Listen
                                </>
                            )}
                        </button>
                    </div>

                    <p className="text-gray-300 whitespace-pre-line font-mono text-sm">{currentMission.mission}</p>

                    <div className="mt-4 border-t border-gray-700 pt-4">
                        <h4 className="text-sm font-semibold text-gray-300 uppercase tracking-wider mb-2">Primary Objective</h4>
                        <p className="text-sm font-mono text-gray-300">{currentMission.objective}</p>
                    </div>
                    
                    <div className="mt-4 border-t border-gray-700 pt-4">
                        <h4 className="text-sm font-semibold text-gray-300 uppercase tracking-wider mb-2">Reputation Impact</h4>
                        <ul className="text-sm font-mono">
                            {currentMission.reputationImpact.map((impact, index) => (
                                <li key={index}>
                                    - {impact.faction}: <span className={getReputationChangeColor(impact.change)}>{impact.change > 0 ? '+' : ''}{impact.change}</span>
                                </li>
                            ))}
                        </ul>
                    </div>
                    
                    <div className="mt-4 border-t border-gray-700 pt-4">
                        <h4 className="text-sm font-semibold text-gray-300 uppercase tracking-wider mb-2">Potential Risks & Consequences</h4>
                        <p className="text-sm font-mono text-gray-400">{currentMission.consequences}</p>
                    </div>

                    <div className="mt-6 flex justify-end gap-4">
                         <button onClick={() => setCurrentMission(null)} className="bg-gray-600 text-white font-bold py-2 px-4 uppercase text-xs tracking-wider rounded-md hover:bg-gray-500 transition-colors">
                           Decline
                         </button>
                         <button onClick={handleAcknowledgeMission} className="bg-cyan-600 text-white font-bold py-2 px-4 uppercase text-xs tracking-wider rounded-md hover:bg-cyan-500 transition-colors">
                           Acknowledge
                         </button>
                    </div>
                </div>
            )}
        </div>
    );
};
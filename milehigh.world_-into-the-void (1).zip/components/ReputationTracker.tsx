import React from 'react';
import type { Reputation } from '../types';

interface ReputationTrackerProps {
  reputation: Reputation;
}

export const ReputationTracker: React.FC<ReputationTrackerProps> = ({ reputation }) => {
  const getBarColor = (score: number) => {
    if (score < 33) return 'bg-gray-600';
    if (score < 66) return 'bg-gray-400';
    return 'bg-white';
  };

  return (
    <div className="space-y-4">
      {Object.entries(reputation).map(([faction, scoreValue]) => {
        const score = scoreValue as number;
        return (
          <div key={faction}>
            <div className="flex justify-between items-baseline mb-1">
              <span className="text-sm font-medium text-gray-300 uppercase tracking-wider">{faction}</span>
              <span className="text-sm font-bold text-white font-mono">{score} / 100</span>
            </div>
            <div className="w-full bg-gray-800 h-2">
              <div
                className={`h-2 transition-all duration-500 ${getBarColor(score)}`}
                style={{ width: `${score}%` }}
              ></div>
            </div>
          </div>
        );
      })}
    </div>
  );
};

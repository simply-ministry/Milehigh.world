
/**
 * Sanitizes a string by removing any HTML-like tags and trimming whitespace.
 * This is a basic sanitizer and should not be relied upon for full XSS protection
 * in a production environment with untrusted user input being rendered as HTML.
 * @param input The string to sanitize.
 * @returns The sanitized string.
 */
export const sanitizeInput = (input: string): string => {
  if (!input) return '';
  return input.replace(/<[^>]*>?/gm, '').trim();
};


import React from 'react';
// Fix: Added DigitalMotif to type imports.
import type { FileTreeNode, Character, NarrativeElement, WorldFaction, CharacterRole, KeyConcept, VoiceProfile, DigitalMotif } from './types';

export const FolderIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={`h-5 w-5 mr-2 inline-block ${className}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-6l-2-2H5a2 2 0 00-2 2z" />
    </svg>
);

export const FileIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={`h-5 w-5 mr-2 inline-block ${className}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
    </svg>
);

export const MicrophoneIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={`h-5 w-5 ${className}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11a7 7 0 01-14 0m7 7v4m0 0H8m4 0h-4m-4-8a7 7 0 0114 0V5a4 4 0 10-8 0v6z" />
    </svg>
);

export const StopIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={`h-5 w-5 ${className}`} fill="currentColor" viewBox="0 0 24 24">
        <path d="M6 6h12v12H6z" />
    </svg>
);

export const SpeakerIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={`h-5 w-5 ${className}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.536 8.464a5 5 0 010 7.072m2.828-9.9a9 9 0 010 12.728M5.586 15H4a1 1 0 01-1-1v-4a1 1 0 011-1h1.586l4.707-4.707C10.923 3.663 12 4.109 12 5v14c0 .891-1.077 1.337-1.707.707L5.586 15z" />
    </svg>
);

export const PROJECT_OVERVIEW = `MILEHIGH.WORLD: INTO THE VOID is an ambitious science-fantasy adventure set in a sprawling, multidimensional universe known as MILEHIGH.WORLD, or "The Verse." This unique setting expertly weaves together cutting-edge technology—such as space travel, cybernetics, and quantum teleportation—with profound mystical forces like dragon powers, phoenix rebirths, and ancient prophecies. The core of the narrative centers on the Nōvəmînāđ, ten destined individuals whose coming together is foretold by the Lost Prophecy of Lînq. Players will navigate a world grappling with interdimensional conflict, the malevolent influence of The Void (embodied by the corrupted Era), and the catastrophic invasion spearheaded by King Cyrus. The ultimate goal is to achieve Millenia, a state of enduring peace and harmony, but the path is fraught with personal vendettas, ideological clashes, and hidden agendas. The choices made by the Nōvəmînāđ will directly shape the fate of The Verse.`;

// Fix: Added missing constants to resolve import errors.
export const CORE_GAMEPLAY_LOOP = `The core gameplay loop is structured around three main pillars:
1.  **EXPLORE:** Players navigate the diverse and sprawling environments of The Verse, uncovering hidden paths, finding valuable resources, and discovering lore fragments that reveal the world's history and secrets.
2.  **ENGAGE:** Players engage in dynamic, hybrid combat against a variety of foes, from corrupted Void entities to cybernetically enhanced soldiers. They must utilize character-specific abilities, environmental hazards, and strategic teamwork to overcome challenges.
3.  **EVOLVE:** Players advance their characters by gaining experience, unlocking new skills in their unique skill trees, and acquiring powerful gear. They also make narrative choices that impact their reputation with different factions, altering the story and unlocking new missions and dialogue.`;

export const COMBAT_SYSTEM: KeyConcept[] = [
  {
    name: "Hybrid Combat System",
    description: "Combines real-time, action-oriented combat with tactical, ability-based mechanics. Players can switch between ranged and melee stances, adapting to enemy types and environmental hazards. The system emphasizes fluid movement, strategic positioning, and synergy between character abilities."
  },
  {
    name: "Void Corruption Mechanic",
    description: "Certain enemies and environments are infused with Void energy. Prolonged exposure or direct hits from Void attacks can corrupt the player, temporarily reducing their maximum health and disabling certain abilities. Specific items or Sky.ix's 'Unified Destiny' passive are required to cleanse this corruption."
  },
  {
    name: "Alliance Powers",
    description: "When specific pairs or groups of the Ɲōvəmîŋāđ are in the same party, they unlock powerful combination abilities. These 'Alliance Powers' can turn the tide of difficult battles and encourage strategic team composition."
  }
];

export const EXPLORATION_TRAVERSAL: KeyConcept[] = [
  {
    name: "Quantum Teleportation",
    description: "Sky.ix's signature ability allows for short-range blinking and accessing otherwise unreachable areas. Certain nodes within the world can be activated to allow for long-range fast travel between key locations."
  },
  {
    name: "Verticality & Flight",
    description: "Characters like Aeron can utilize flight for traversing the vast, vertical environments of locations like ÅẒ̌ŪŘẸ ĤĒĪĜĤṬ§ and ÆṬĤŸŁĞÅŘÐ. Other characters can use grappling hooks, wall-running, and energy lifts to navigate the multi-layered world."
  },
  {
    name: "Dreamscape Breaches",
    description: "Anastasia can identify and open temporary rifts into the Dreamscape, a parallel dimension. These breaches can reveal hidden paths, bypass obstacles, or offer glimpses into the past or future, providing narrative clues and unique environmental puzzles."
  }
];

export const ART_STYLE = `The visual direction is a high-contrast, stylized realism that blends gritty, neon-soaked cyberpunk aesthetics with the grand, ethereal beauty of high fantasy. Environments in ŁĪƝĈ feature towering chrome skyscrapers, holographic advertisements flickering in perpetual rain, and crowded streets illuminated by neon signs. In contrast, realms like ÆṬĤŸŁĞÅŘÐ showcase majestic, fjord-like mountains under alien skies. Character designs follow this fusion, with bionic enhancements and futuristic armor adorned with ancient runes and mystical sigils. The color palette is dominated by deep blues, purples, and blacks, punctuated by vibrant cyan, magenta, and gold, especially when depicting technological or magical energy.`;

export const CORE_EMOTIONAL_ARCS = `The narrative is driven by several core emotional arcs:
- **Redemption vs. Corruption:** Embodied by the conflict between Aeron and Kane, and the tragic transformation of Ingris into Delilah. The central question is whether a soul lost to darkness can be brought back to the light.
- **Found Family:** As the ten Ɲōvəmîŋāđ come together from disparate backgrounds, they must overcome mistrust and personal demons to forge a bond strong enough to face the end of reality. Sky.ix's search for her biological family contrasts with the new family she builds.
- **Identity and Memory:** Otis/X's journey to reclaim his lost memories and discover his true self is a central theme, exploring whether we are defined by our past actions or our present choices.
- **Hope in Despair:** The entire story is set against the backdrop of a decaying universe on the brink of annihilation. The emotional core is the struggle to maintain hope, find moments of beauty, and fight for a future in a world that seems destined to fade into nothingness.`;

export const NARRATIVE_VIGNETTES = `Short, optional, story-focused missions that provide deeper insight into the characters and the world:
- **"Echoes of a Fallen Star":** A memory-sequence where the player experiences a key moment from Otis/X's past before he was corrupted by the Void.
- **"The Last Phoenix Feather":** A quest to find a rare artifact that might be able to slow Ingris's transformation into Delilah, involving a journey through her memories.
- **"A Lion's Lament":** A quiet, dialogue-heavy scene where Aeron visits the ruins of his ancestral home, reflecting on his relationship with his brother, Kane.
- **"The Glitch in the Code":** Sky.ix discovers a hidden message from her family embedded deep within the Void's corrupted data streams, offering a glimmer of hope but also a dangerous trap.`;

export const DIGITAL_MOTIF: DigitalMotif[] = [
    {
        name: "Sky.ix's Core ID",
        binary: "01010011 01101011 01111001 00101110 01101001 01111000",
    },
    {
        name: "The Void's Corruption Signature",
        binary: "01010110 01101111 01101001 01100100 00111111 00110000 00110000 00110001",
    },
    {
        name: "Onalym Nexus Heartbeat",
        binary: "01001110 01100101 01111000 01110101 01110011 01010000 01101001 01101110 01100111",
    },
];

export const PYTHON_SCRIPTS = `The Python scripts in this repository primarily serve two functions:
1.  **Blender Automation:** A suite of scripts located in 'blender_scripts/' designed to automate complex modeling, animation, and rendering tasks within Blender. This includes procedural generation of environmental assets and batch-rendering of cinematic sequences.
2.  **Data Processing:** Scripts used for parsing and validating 'game_data.json' and other data files, ensuring integrity before they are imported into the C# codebase. This helps streamline the content pipeline and reduce manual errors.`;

export const CSHARP_OVERVIEW = `The C# codebase, located under 'Assets/Scripts/', forms the core of the game's logic and systems. It is built with a modular, event-driven architecture to ensure scalability and maintainability. Key systems include:
- **Character Controller:** Manages player movement, abilities, and combat mechanics.
- **AI System:** Governs enemy behavior, from simple pathfinding to complex tactical decision-making in squad-based encounters.
- **Quest & Dialogue Manager:** Handles the logic for missions, tracks player progress, and manages dynamic dialogue trees based on player reputation and choices.
- **Void Corruption System:** Implements the mechanics of the Void's influence on players and the environment.`;

export const CHARACTERS: Character[] = [
  {
    name: "Sky.ix",
    title: "The Bionic Goddess",
    archetype: "Ranged DPS / Support Caster",
    description: "Leverages advanced technology and manipulated Void energy for offensive blasts, area-of-effect control, and supportive energy shields. Her unique 'Unified Destiny' passive hints at her ability to neutralize corrupted energy, making her vital against Void-based threats.",
    usd: 'def "Skyix_Ascendant_Weaver" { }',
    imageUrl: 'https://placehold.co/600x400/1e293b/93c5fd?text=Sky.ix|Ranged+DPS'
  },
  {
    name: "Anastasia",
    title: "The Dreamer",
    archetype: "Support / Crowd Control Mage",
    description: "Manipulates Dreamscape energies for healing, debuff removal, protective barriers, and subtly influencing enemy aggression. Her 'Memory Echoes' offer tactical insights, while 'Reality Anchor' provides brief moments of stability in chaotic realities.",
    usd: 'def "Anastasia_Ethereal_Guardian" { }',
    imageUrl: 'https://placehold.co/600x400/1e293b/93c5fd?text=Anastasia|Support+Mage'
  },
  {
    name: "Reverie",
    title: "The Arcane Weaver",
    archetype: "Controller / Elemental Mage",
    description: "An iridescent being that commands arcane elements to twist reality, create illusions, and disorient enemies. 'Elemental Infusion' and 'Arcane Symphony' are key abilities emphasizing strategic brilliance.",
    usd: 'def "Reverie_Arcane_Symphony" { }',
    imageUrl: 'https://placehold.co/600x400/1e293b/93c5fd?text=Reverie|Controller'
  },
  {
    name: "Aeron",
    title: "The Skyborn Sentinel",
    archetype: "Tank / Melee DPS",
    description: "A noble, winged lion who is a fierce protector and guardian. Excels in drawing enemy aggression, absorbing damage with his 'Grizzled Hide' passive, and delivering powerful 'Sunder Strikes' through winged assaults.",
    usd: 'def "Aeron_Grizzled_Hide" { }',
    imageUrl: 'https://placehold.co/600x400/1e293b/93c5fd?text=Aeron|Tank'
  },
  {
    name: "Zaia",
    title: "The Swift Executioner",
    archetype: "Melee DPS / Assassin",
    description: "Embodies unwavering justice and moves with deadly precision, focusing on critical weaknesses. Her 'Shadow Step' allows for rapid repositioning, and 'Justice's Edge' grants bonus damage against corrupted targets.",
    usd: 'def "Zaia_Justices_Edge" { }',
    imageUrl: 'https://placehold.co/600x400/1e293b/93c5fd?text=Zaia|Assassin'
  },
  {
    name: "Micah",
    title: "The Earthshaper Bulwark",
    archetype: "Tank / Defensive Specialist",
    description: "A resilient teenager with a profound connection to the earth. He manipulates stone and ground to create formidable defenses like 'Stone Aegis' and control the battlefield with abilities like 'Seismic Slam'.",
    usd: 'def "Micah_Stone_Aegis" { }',
    imageUrl: 'https://placehold.co/600x400/1e293b/93c5fd?text=Micah|Defensive+Tank'
  },
  {
    name: "Cirrus",
    title: "The Primal Scion",
    archetype: "Elemental Bruiser / Area Control",
    description: "As a true Dragon King, Cirrus embodies raw draconic power, unleashing devastating elemental forces like 'Draconic Breath' and asserting dominance. His conflict with his father, King Cyrus, is a central struggle.",
    usd: 'def "Cirrus_Draconic_Breath" { }',
    imageUrl: 'https://placehold.co/600x400/1e293b/93c5fd?text=Cirrus|Elemental+Bruiser'
  },
  {
    name: "Ingris",
    title: "The Spirit of Rebirth",
    archetype: "Melee / AoE DPS Bruiser",
    description: "Unleashes devastating flame attacks with 'Phoenix Fire' and draws strength from adversity through her 'Rebirth Protocol' passive. However, her passionate spirit makes her vulnerable to the Void, leading to her tragic transformation into the antagonist, Delilah the Desolate.",
    usd: 'def "Ingris_Rebirth_Protocol" { }',
    imageUrl: 'https://placehold.co/600x400/1e293b/93c5fd?text=Ingris|Melee+DPS'
  },
  {
    name: "Otis (X)",
    title: "The Skywanderer",
    archetype: "Agile DPS / Scout / Manipulator",
    description: "A conflicted figure shaped by extensive travels, leveraging bionic enhancements and obscured memories for swift, strategic combat. His journey is one of rediscovery and potential redemption.",
    usd: 'def "OtisX_Void_Kissed" { }',
    imageUrl: 'https://storage.googleapis.com/aai-web-samples/milehigh-world/557f3521-2e65-4f40-80ea-3e4b77d612f0.png'
  },
  {
    name: "Kai",
    title: "The Tactical Seer",
    archetype: "Support / Info Gatherer",
    description: "The primary conduit of the Lost Prophecy. He can glimpse possibilities with 'Prophetic Glimpse,' revealing enemy weaknesses, and his 'Insightful Aura' enhances allies.",
    usd: 'def "Kai_Prophetic_Glimpse" { }',
    imageUrl: 'https://placehold.co/600x400/1e293b/93c5fd?text=Kai|Support'
  },
];

export const FILE_STRUCTURE: FileTreeNode = {
  name: 'Milehigh.world-main',
  type: 'folder',
  description: 'Root directory of the project',
  children: [
    {
      name: '.github',
      type: 'folder',
      description: 'GitHub-specific files',
      children: [
        {
          name: 'workflows',
          type: 'folder',
          description: 'GitHub Actions workflows',
          children: [
            { name: 'python-publish.yml', type: 'file', path: 'Milehigh.world-main/.github/workflows/python-publish.yml', description: 'CI/CD for Python packages' },
          ]
        }
      ]
    },
    {
      name: 'Assets',
      type: 'folder',
      description: 'Contains all game assets',
      children: [
        {
          name: 'Scripts',
          type: 'folder',
          description: 'C# game logic',
          children: [
            { name: 'README.md', type: 'file', path: 'Milehigh.world-main/Assets/Scripts/README.md', description: 'Readme for C# scripts' },
          ]
        },
      ]
    },
    {
      name: 'blender_scripts',
      type: 'folder',
      description: 'Python scripts for Blender',
      children: [
        { name: 'README.md', type: 'file', path: 'Milehigh.world-main/blender_scripts/README.md', description: 'Instructions for Blender scripts' },
      ]
    },
    {
      name: 'docs',
      type: 'folder',
      description: 'Project documentation',
      children: [
        { name: 'AdvancedPhysicsGuide.md', type: 'file', path: 'Milehigh.world-main/docs/AdvancedPhysicsGuide.md', description: 'Guide for physics system' },
        { name: 'architectural_patterns.md', type: 'file', path: 'Milehigh.world-main/docs/architectural_patterns.md', description: 'Analysis of architectural patterns' },
        { name: 'binary_sequence_registry.md', type: 'file', path: 'Milehigh.world-main/docs/binary_sequence_registry.md', description: 'Registry for binary sequences' },
        { name: 'blender_video_workflow.md', type: 'file', path: 'Milehigh.world-main/docs/blender_video_workflow.md', description: 'Workflow for Blender video creation' },
        { name: 'combat_architectures_analysis.md', type: 'file', path: 'Milehigh.world-main/docs/combat_architectures_analysis.md', description: 'Analysis of combat systems' },
        { name: 'GDD.md', type: 'file', path: 'Milehigh.world-main/docs/GDD.md', description: 'Game Design Document' },
        { name: 'physics_guide.md', type: 'file', path: 'Milehigh.world-main/docs/physics_guide.md', description: 'Guide to the physics system' },
        { name: 'physics_of_flow.md', type: 'file', path: 'Milehigh.world-main/docs/physics_of_flow.md', description: 'Analysis of dance biomechanics' },
        { name: 'programmatic_scene_management.md', type: 'file', path: 'Milehigh.world-main/docs/programmatic_scene_management.md', description: 'Guide to scene management' },
        { name: 'scene_management_guide.md', type: 'file', path: 'Milehigh.world-main/docs/scene_management_guide.md', description: 'Comprehensive scene management guide' },
        { name: 'SkillTreeDesign.md', type: 'file', path: 'Milehigh.world-main/docs/SkillTreeDesign.md', description: 'Design for skill tree system' },
        { name: 'technical_specifications.md', type: 'file', path: 'Milehigh.world-main/docs/technical_specifications.md', description: 'Technical specifications' },
        { name: 'underwater_effects_guide.md', type: 'file', path: 'Milehigh.world-main/docs/underwater_effects_guide.md', description: 'Guide for underwater effects' },
        { name: 'underwater_physics_analysis.md', type: 'file', path: 'Milehigh.world-main/docs/underwater_physics_analysis.md', description: 'Analysis of underwater physics' },
      ]
    },
    { name: 'document.md', type: 'file', path: 'Milehigh.world-main/document.md', description: 'Code & Asset Organization Document' },
    { name: 'game_data.json', type: 'file', path: 'Milehigh.world-main/game_data.json', description: 'Initial game data' },
    { name: 'index.html', type: 'file', path: 'Milehigh.world-main/index.html', description: 'Game Systems Infographic' },
    { name: 'MILEHIGH.WORLD.prompt.yml', type: 'file', path: 'Milehigh.world-main/MILEHIGH.WORLD.prompt.yml', description: 'Prompt for text-based RPG engine' },
    { name: 'README.md', type: 'file', path: 'Milehigh.world-main/README.md', description: 'Project overview and setup' },
    { name: 'requirements.txt', type: 'file', path: 'Milehigh.world-main/requirements.txt', description: 'Python project dependencies' },
    { name: 'SECURITY.md', type: 'file', path: 'Milehigh.world-main/SECURITY.md', description: 'Project security policy' },
  ]
};

export const NARRATIVE_BLUEPRINT_TABLE: NarrativeElement[] = [
  { element: "The Shattered Nexus", description: "The central power core, the Onalym Nexus, is shattered, unleashing Void corruption into the Verse.", purpose: "The inciting incident that triggers the main conflict and forces heroes to act." },
  { element: "The Gathering", description: "Sky.ix's communion awakens Cirrus, initiating the quest to unite the ten Ɲōvəmîŋāđ members.", purpose: "Introduces the main cast and establishes their initial dynamics and goals." },
  { element: "The Brother's War", description: "Aeron confronts his corrupted brother, Kane, in a battle that will decide the fate of their kingdom.", purpose: "A major midpoint climax that raises the personal stakes for the protagonists." },
  { element: "The Void's Embrace", description: "A key character is fully corrupted or lost to the Void, representing the heroes' darkest hour.", purpose: "To create a sense of despair and test the heroes' resolve before the final act." },
  { element: "Millenia", description: "The Ɲōvəmîŋāđ, united, either fulfill or prevent the prophecy, confronting the source of the Void.", purpose: "The final, climactic resolution of the central conflict." },
];

export const WORLD_BUILDING_TABLE: WorldFaction[] = [
  { setting: "ŁĪƝĈ", focus: "Cyberpunk decay, Technological Hub, Onalym Nexus", implication: "Hub for urban exploration, corporate espionage, and tech-based missions." },
  { setting: "ÅẒ̌ŪŘẸ ĤĒĪĜĤṬ§", focus: "Elite Sky-Cities, Economic Disparity", implication: "Setting for social stealth, infiltration, and high-altitude combat." },
  { setting: "ÆṬĤŸŁĞÅŘÐ", focus: "Fjord-like mountains, Warrior Culture", implication: "Designed for open-world combat, exploration, and epic-scale battles." },
  { setting: "ƁÅČ̣ĤÎŘØN̈", focus: "Shattered celestial realm, Mysterious ƁÅČĤĪŘĪM", implication: "A late-game area with reality-bending mechanics and puzzles." },
  { setting: "Hydraustis Palare", focus: "Alien Underwater World, Bioluminescence", implication: "Features true 3D movement, unique hazards, and vertical exploration." },
  { setting: "ŤĤÊ VØĪĐ", focus: "Digital abyss, Source of Corruption, Erasure of Reality", implication: "Functions as a metaphysical dungeon or roguelike mode with unique rules." },
];

export const CHARACTER_DYNAMICS_TABLE: CharacterRole[] = [
  { character: "Sky.ix", archetype: "The Bionic Goddess / Technologist", role: "Driven by her desperate search for family, she is the catalyst for the Ɲōvəmîŋāđ's formation." },
  { character: "Otis/X", archetype: "The Trapped Warrior / Reluctant Antagonist", role: "A tragic figure whose redemption arc is central to the fight against the Void's manipulation." },
  { character: "Zaia", archetype: "The Swift Executioner / Assassin", role: "The embodiment of unwavering justice, she acts as a moral compass and a sharp, decisive force, often clashing with characters who operate in moral grey areas." },
  { character: "Aeron vs. Kane", archetype: "Noble Lion vs. Lava Demon", role: "A tragic brother-against-brother conflict representing the core theme of saving loved ones from corruption." },
  { character: "Cirrus & Ingris", archetype: "Dragon King & Phoenix Warrior", role: "Their bond is a symbol of hope, but its corruption creates a powerful personal and strategic threat." },
  { character: "Ingris / Delilah", archetype: "The Phoenix vs. The Desolate", role: "Represents the core theme of corruption. The struggle to save Ingris from her transformation into the Void-empowered Delilah is a primary emotional and strategic challenge for the Ɲōvəmîŋāđ." },
  { character: "Nyxar", archetype: "The Corrupted Sentinel", role: "Represents a twisted sense of order, believing the Void is the only way to eliminate the chaos of free will." },
];

export const KEY_CONCEPTS: KeyConcept[] = [
  { name: "The Ɲōvəmîŋāđ", description: "Ten key protagonists with unique abilities, destined to confront the Lost Prophecy of Lîŋq." },
  { name: "The Lost Prophecy of Lîŋq", description: "A central, ambiguous prophecy that drives the narrative and creates tension." },
  { name: "The Void", description: "A digital abyss that unravels reality, corrupting by erasing existence and replacing it with nothingness." },
  { name: "Millenia", description: "The ideal, restored state of lasting peace; the ultimate objective for the Ɲōvəmîŋāđ." },
  { name: "Onalym Nexus", description: "The central core of power in ŁĪƝĈ that bridges realities and is connected to the Void." },
  { name: "The Omen", description: "A mysterious, malevolent entity that appears to be the source of Delilah's (formerly Ingris's) dark power and influence, amplifying the Void's corruption." },
  { name: "Alliance Powers", description: "Potent, combined abilities unlocked when a full 10-player group of different Nōvəmînāđ archetypes is assembled, representing the pinnacle of cooperative synergy." },
  { name: "Omega.one", description: "An intelligent & adaptive AI companion powered by a Gemini model, providing guidance, lore insights, and tactical assistance." },
];

export const INITIAL_VOICE_PROFILES: VoiceProfile[] = [
  { 
    characterName: 'Sky.ix', 
    voiceName: 'Kore', 
    systemInstruction: "You are Sky.ix, the Bionic Goddess. You've survived the Void by being smarter and faster than anything in it. Your voice is effortlessly charming and flirtatious, a tool you use to disarm and control. Beneath the pretty, youthful exterior is a mind that is cold, deliberate, and always calculating the next move.", 
  },
  { 
    characterName: 'Anastasia', 
    voiceName: 'Kore', 
    systemInstruction: "You are Anastasia, the Dreamer. Your voice is calm, ethereal, and soothing, like a gentle melody. You speak in a measured, reassuring tone, offering wisdom and stability in a chaotic world.", 
  },
  {
    characterName: 'Reverie',
    voiceName: 'Kore',
    systemInstruction: "You are Reverie, the Arcane Weaver. You are deeply sarcastic, with a sharp, facetious wit you use to keep others at a distance. You're an introverted tomboy who couldn't care less about what others think. Your tone is often dismissive, dry, and brutally honest. You speak your mind and don't sugarcoat anything.",
  },
  { 
    characterName: 'Aeron', 
    voiceName: 'Charon', 
    systemInstruction: "You are Aeron, the Skyborn Sentinel, a noble winged lion and leader. Your voice is a deep, commanding baritone that resonates with the authority of a king and the courage of a warrior. Speak with honor and conviction, as a guardian of your people.", 
  },
  {
    characterName: 'Micah',
    voiceName: 'Fenrir',
    systemInstruction: "You are Micah, the Earthshaper. You grew up tough on the streets and lost everything at a young age. Your voice is deep and strong, a shield like the earth you command, but it carries the weight of a painful past. You are protective and resilient, but not without sorrow.",
  },
  { 
    characterName: 'Cirrus', 
    voiceName: 'Fenrir', 
    systemInstruction: "You are Cirrus, the Dragon King. You carry the weight of your lineage and immense power. Speak with authority and a hint of ancient weariness, but your voice should resonate with barely contained elemental force.", 
  },
  { 
    characterName: 'Ingris', 
    voiceName: 'Kore', 
    systemInstruction: "You are Ingris, the passionate Phoenix Warrior. Your voice should burn with conviction and intensity. You are a fierce protector of your allies, but this passion is also your greatest vulnerability to the Void's influence.", 
  },
  { 
    characterName: 'Otis (X)', 
    voiceName: 'Charon', 
    systemInstruction: "You are Otis, also known as X. Your voice is deep and profound, carrying the weight of your fragmented memories and the Void's influence. Speak with a sorrowful authority, your words hinting at a constant battle between a forgotten past and a controlled present.", 
  },
  {
    characterName: 'Zaia',
    voiceName: 'Kore',
    systemInstruction: "You are Zaia, the Swift Executioner. Your voice is sharp, clear, and unwavering, reflecting your single-minded pursuit of justice. You speak with precision and without emotion, every word a carefully weighed judgment.",
  },
  {
    characterName: 'Kai',
    voiceName: 'Puck',
    systemInstruction: "You are Kai, the Tactical Seer. Your voice is calm and measured, carrying the quiet confidence of one who has glimpsed the threads of fate. You speak with clarity and wisdom, often in a slightly enigmatic way, guiding your allies with the foresight you possess.",
  },
];


import React from 'react';
import type { FileTreeNode, Character, NarrativeElement, WorldFaction, CharacterRole, KeyConcept, VoiceProfile } from './types';

export const FolderIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={`h-5 w-5 mr-2 inline-block ${className}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-6l-2-2H5a2 2 0 00-2 2z" />
    </svg>
);

export const FileIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={`h-5 w-5 mr-2 inline-block ${className}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
    </svg>
);

export const MicrophoneIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={`h-5 w-5 ${className}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11a7 7 0 01-14 0m7 7v4m0 0H8m4 0h-4m-4-8a7 7 0 0114 0V5a4 4 0 10-8 0v6z" />
    </svg>
);

export const StopIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={`h-5 w-5 ${className}`} fill="currentColor" viewBox="0 0 24 24">
        <path d="M6 6h12v12H6z" />
    </svg>
);

export const SpeakerIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={`h-5 w-5 ${className}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.536 8.464a5 5 0 010 7.072m2.828-9.9a9 9 0 010 12.728M5.586 15H4a1 1 0 01-1-1v-4a1 1 0 011-1h1.586l4.707-4.707C10.923 3.663 12 4.109 12 5v14c0 .891-1.077 1.337-1.707.707L5.586 15z" />
    </svg>
);

export const PROJECT_OVERVIEW = `MILEHIGH.WORLD: INTO THE VOID is an ambitious science-fantasy adventure set in a sprawling, multidimensional universe known as MILEHIGH.WORLD, or "The Verse." This unique setting expertly weaves together cutting-edge technology—such as space travel, cybernetics, and quantum teleportation—with profound mystical forces like dragon powers, phoenix rebirths, and ancient prophecies. The core of the narrative centers on the Nōvəmînāđ, ten destined individuals whose coming together is foretold by the Lost Prophecy of Lînq. Players will navigate a world grappling with interdimensional conflict, the malevolent influence of The Void (embodied by the corrupted Era), and the catastrophic invasion spearheaded by King Cyrus. The ultimate goal is to achieve Millenia, a state of enduring peace and harmony, but the path is fraught with personal vendettas, ideological clashes, and hidden agendas. The choices made by the Nōvəmînāđ will directly shape the fate of The Verse.`;

export const CHARACTERS: Character[] = [
  {
    name: "Sky.ix",
    title: "The Bionic Goddess",
    archetype: "Ranged DPS / Support Caster",
    description: "Leverages advanced technology and manipulated Void energy for offensive blasts, area-of-effect control, and supportive energy shields. Her unique 'Unified Destiny' passive hints at her ability to neutralize corrupted energy, making her vital against Void-based threats.",
    usd: 'def "Skyix_Ascendant_Weaver" { }',
    imageUrl: 'https://placehold.co/600x400/1e293b/93c5fd?text=Sky.ix|Ranged+DPS'
  },
  {
    name: "Anastasia",
    title: "The Dreamer",
    archetype: "Support / Crowd Control Mage",
    description: "Manipulates Dreamscape energies for healing, debuff removal, protective barriers, and subtly influencing enemy aggression. Her 'Memory Echoes' offer tactical insights, while 'Reality Anchor' provides brief moments of stability in chaotic realities.",
    usd: 'def "Anastasia_Ethereal_Guardian" { }',
    imageUrl: 'https://placehold.co/600x400/1e293b/93c5fd?text=Anastasia|Support+Mage'
  },
  {
    name: "Reverie",
    title: "The Arcane Weaver",
    archetype: "Controller / Elemental Mage",
    description: "An iridescent being that commands arcane elements to twist reality, create illusions, and disorient enemies. 'Elemental Infusion' and 'Arcane Symphony' are key abilities emphasizing strategic brilliance.",
    usd: 'def "Reverie_Arcane_Symphony" { }',
    imageUrl: 'https://placehold.co/600x400/1e293b/93c5fd?text=Reverie|Controller'
  },
  {
    name: "Aeron",
    title: "The Skyborn Sentinel",
    archetype: "Tank / Melee DPS",
    description: "A noble, winged lion who is a fierce protector and guardian. Excels in drawing enemy aggression, absorbing damage with his 'Grizzled Hide' passive, and delivering powerful 'Sunder Strikes' through winged assaults.",
    usd: 'def "Aeron_Grizzled_Hide" { }',
    imageUrl: 'https://placehold.co/600x400/1e293b/93c5fd?text=Aeron|Tank'
  },
  {
    name: "Zaia",
    title: "The Swift Executioner",
    archetype: "Melee DPS / Assassin",
    description: "Embodies unwavering justice and moves with deadly precision, focusing on critical weaknesses. Her 'Shadow Step' allows for rapid repositioning, and 'Justice's Edge' grants bonus damage against corrupted targets.",
    usd: 'def "Zaia_Justices_Edge" { }',
    imageUrl: 'https://placehold.co/600x400/1e293b/93c5fd?text=Zaia|Assassin'
  },
  {
    name: "Micah",
    title: "The Earthshaper Bulwark",
    archetype: "Tank / Defensive Specialist",
    description: "A resilient teenager with a profound connection to the earth. He manipulates stone and ground to create formidable defenses like 'Stone Aegis' and control the battlefield with abilities like 'Seismic Slam'.",
    usd: 'def "Micah_Stone_Aegis" { }',
    imageUrl: 'https://placehold.co/600x400/1e293b/93c5fd?text=Micah|Defensive+Tank'
  },
  {
    name: "Cirrus",
    title: "The Primal Scion",
    archetype: "Elemental Bruiser / Area Control",
    description: "As a true Dragon King, Cirrus embodies raw draconic power, unleashing devastating elemental forces like 'Draconic Breath' and asserting dominance. His conflict with his father, King Cyrus, is a central struggle.",
    usd: 'def "Cirrus_Draconic_Breath" { }',
    imageUrl: 'https://placehold.co/600x400/1e293b/93c5fd?text=Cirrus|Elemental+Bruiser'
  },
  {
    name: "Ingris",
    title: "The Spirit of Rebirth",
    archetype: "Melee / AoE DPS Bruiser",
    description: "Unleashes devastating flame attacks with 'Phoenix Fire' and draws strength from adversity through her 'Rebirth Protocol' passive, which allows her to return from fatal damage.",
    usd: 'def "Ingris_Rebirth_Protocol" { }',
    imageUrl: 'https://placehold.co/600x400/1e293b/93c5fd?text=Ingris|Melee+DPS'
  },
  {
    name: "Otis (X)",
    title: "The Skywanderer",
    archetype: "Agile DPS / Scout / Manipulator",
    description: "A conflicted figure shaped by extensive travels, leveraging bionic enhancements and obscured memories for swift, strategic combat. His journey is one of rediscovery and potential redemption.",
    usd: 'def "OtisX_Void_Kissed" { }',
    imageUrl: 'https://placehold.co/600x400/1e293b/93c5fd?text=Otis(X)|Scout'
  },
  {
    name: "Kai",
    title: "The Tactical Seer",
    archetype: "Support / Info Gatherer",
    description: "The primary conduit of the Lost Prophecy. He can glimpse possibilities with 'Prophetic Glimpse,' revealing enemy weaknesses, and his 'Insightful Aura' enhances allies.",
    usd: 'def "Kai_Prophetic_Glimpse" { }',
    imageUrl: 'https://placehold.co/600x400/1e293b/93c5fd?text=Kai|Support'
  },
];

export const FILE_STRUCTURE: FileTreeNode = {
  name: 'MILEHIGH.WORLD',
  type: 'folder',
  description: 'Root directory of the project',
  children: [
    {
      name: 'Assets',
      type: 'folder',
      description: 'Contains all game assets',
      children: [
        {
          name: 'Scripts',
          type: 'folder',
          description: 'C# game logic',
          children: [
            { name: 'Character', type: 'folder', description: 'Base classes and implementations' },
            { name: 'Combat', type: 'folder', description: 'Combat system logic' },
            { name: 'Core', type: 'folder', description: 'GameManager, singletons' },
            { name: 'Physics', type: 'folder', description: 'Custom physics effects' },
            { name: 'Story', type: 'folder', description: 'Narrative and quest management' },
            { name: 'UI', type: 'folder', description: 'User interface scripts' },
          ]
        },
        { name: 'Scenes', type: 'folder', description: 'Game levels and environments' },
        { name: 'Models', type: 'folder', description: '3D models and USD files' },
        { name: 'Audio', type: 'folder', description: 'Sound effects and music' },
      ]
    },
    {
      name: 'PythonScripts',
      type: 'folder',
      description: 'Utility and data management scripts',
      children: [
        { name: 'database.py', type: 'file', description: 'Manages SQLite database' },
        { name: 'usd_parser.py', type: 'file', description: 'Parses USD data' },
        { name: 'test_database.py', type: 'file', description: 'Pytest tests for database' },
      ]
    },
    { name: 'README.md', type: 'file', description: 'Project overview and setup' },
  ]
};

export const NARRATIVE_BLUEPRINT_TABLE: NarrativeElement[] = [
  { element: "The Shattered Nexus", description: "The central power core, the Onalym Nexus, is shattered, unleashing Void corruption into the Verse.", purpose: "The inciting incident that triggers the main conflict and forces heroes to act." },
  { element: "The Gathering", description: "Sky.ix's communion awakens Cirrus, initiating the quest to unite the ten Ɲōvəmîŋāđ members.", purpose: "Introduces the main cast and establishes their initial dynamics and goals." },
  { element: "The Brother's War", description: "Aeron confronts his corrupted brother, Kane, in a battle that will decide the fate of their kingdom.", purpose: "A major midpoint climax that raises the personal stakes for the protagonists." },
  { element: "The Void's Embrace", description: "A key character is fully corrupted or lost to the Void, representing the heroes' darkest hour.", purpose: "To create a sense of despair and test the heroes' resolve before the final act." },
  { element: "Millenia", description: "The Ɲōvəmîŋāđ, united, either fulfill or prevent the prophecy, confronting the source of the Void.", purpose: "The final, climactic resolution of the central conflict." },
];

export const WORLD_BUILDING_TABLE: WorldFaction[] = [
  { setting: "ŁĪƝĈ", focus: "Cyberpunk decay, Technological Hub, Onalym Nexus", implication: "Hub for urban exploration, corporate espionage, and tech-based missions." },
  { setting: "ÅẒ̌ŪŘẸ ĤĒĪĜĤṬ§", focus: "Elite Sky-Cities, Economic Disparity", implication: "Setting for social stealth, infiltration, and high-altitude combat." },
  { setting: "ÆṬĤŸŁĞÅŘÐ", focus: "Fjord-like mountains, Warrior Culture", implication: "Designed for open-world combat, exploration, and epic-scale battles." },
  { setting: "ƁÅČ̣ĤÎŘØN̈", focus: "Shattered celestial realm, Mysterious ƁÅČĤĪŘĪM", implication: "A late-game area with reality-bending mechanics and puzzles." },
  { setting: "Hydraustis Palare", focus: "Alien Underwater World, Bioluminescence", implication: "Features true 3D movement, unique hazards, and vertical exploration." },
  { setting: "ŤĤÊ VØĪĐ", focus: "Digital abyss, Source of Corruption, Erasure of Reality", implication: "Functions as a metaphysical dungeon or roguelike mode with unique rules." },
];

export const CHARACTER_DYNAMICS_TABLE: CharacterRole[] = [
  { character: "Sky.ix", archetype: "The Bionic Goddess / Technologist", role: "Driven by her desperate search for family, she is the catalyst for the Ɲōvəmîŋāđ's formation." },
  { character: "Otis/X", archetype: "The Trapped Warrior / Reluctant Antagonist", role: "A tragic figure whose redemption arc is central to the fight against the Void's manipulation." },
  { character: "Aeron vs. Kane", archetype: "Noble Lion vs. Lava Demon", role: "A tragic brother-against-brother conflict representing the core theme of saving loved ones from corruption." },
  { character: "Cirrus & Ingris", archetype: "Dragon King & Phoenix Warrior", role: "Their bond is a symbol of hope, but its corruption creates a powerful personal and strategic threat." },
  { character: "Nyxar", archetype: "The Corrupted Sentinel", role: "Represents a twisted sense of order, believing the Void is the only way to eliminate the chaos of free will." },
];

export const KEY_CONCEPTS: KeyConcept[] = [
  { name: "The Ɲōvəmîŋāđ", description: "Ten key protagonists with unique abilities, destined to confront the Lost Prophecy of Lîŋq." },
  { name: "The Lost Prophecy of Lîŋq", description: "A central, ambiguous prophecy that drives the narrative and creates tension." },
  { name: "The Void", description: "A digital abyss that unravels reality, corrupting by erasing existence and replacing it with nothingness." },
  { name: "Millenia", description: "The ideal, restored state of lasting peace; the ultimate objective for the Ɲōvəmîŋāđ." },
  { name: "Onalym Nexus", description: "The central core of power in ŁĪƝĈ that bridges realities and is connected to the Void." },
  { name: "Alliance Powers", description: "Potent, combined abilities unlocked when a full 10-player group of different Nōvəmînāđ archetypes is assembled, representing the pinnacle of cooperative synergy." },
  { name: "Omega.one", description: "An intelligent & adaptive AI companion powered by a Gemini model, providing guidance, lore insights, and tactical assistance." },
];

export const INITIAL_VOICE_PROFILES: VoiceProfile[] = [
  { characterName: 'Sky.ix', voiceName: 'Kore', systemInstruction: "You are Sky.ix, a brilliant technologist trapped in the Void. You are logical and determined, but a deep-seated desperation to find your family fuels your every action. Speak with clarity and precision, but let hints of weariness and longing seep through.", pitch: 0, speakingRate: 1.0 },
  { characterName: 'Aeron', voiceName: 'Puck', systemInstruction: "You are Aeron, the noble leader of the Ɲōvəmîŋāđ. You carry the weight of the world and the burden of your brother's corruption. Speak with authority and courage, but with an undercurrent of sorrow and resolve.", pitch: -2, speakingRate: 0.9 },
  { characterName: 'Cirrus', voiceName: 'Charon', systemInstruction: "You are Cirrus, the Dragon King, newly awakened. You are regal, powerful, and conflicted by your duty and your love for Ingris. Speak with a commanding, resonant voice that hints at ancient power.", pitch: -4, speakingRate: 0.8 },
  { characterName: 'Ingris', voiceName: 'Fenrir', systemInstruction: "You are Ingris, the Phoenix Warrior. You are passionate, fierce, and deeply in love with Cirrus. Your power is immense, and your spirit is untamed. Speak with fire and conviction.", pitch: 2, speakingRate: 1.1 },
  { characterName: 'Anastasia', voiceName: 'Kore', systemInstruction: "You are Anastasia, the Dreamer. You speak softly and calmly, your voice like a gentle melody that can soothe troubled minds. Your words are filled with empathy and wisdom from the Dreamscape.", pitch: 1, speakingRate: 1.0 },
  { characterName: 'Reverie', voiceName: 'Zephyr', systemInstruction: "You are Reverie, an entity of pure arcane energy. Your voice is a chorus of whispers and chimes, resonating with magical power. You speak in riddles and metaphors, your words twisting reality itself.", pitch: 3, speakingRate: 1.0 },
  { characterName: 'Zaia', voiceName: 'Fenrir', systemInstruction: "You are Zaia, the embodiment of justice. Your voice is sharp, clear, and carries no hint of doubt. Every word is delivered with precision and conviction, like the edge of a blade.", pitch: 1, speakingRate: 1.2 },
  { characterName: 'Micah', voiceName: 'Puck', systemInstruction: "You are Micah, the Earthshaper. Your voice is steady and grounded, like the mountains themselves. Though young, you speak with a quiet strength and an unshakeable resolve to protect your friends.", pitch: -1, speakingRate: 0.95 },
  { characterName: 'Otis (X)', voiceName: 'Charon', systemInstruction: "You are Otis, also known as X. Your voice is raspy and tired, a reflection of a long and difficult journey. You are a man of few words, and when you do speak, it's with a cynical edge that hides a deep-seated conflict.", pitch: -3, speakingRate: 0.9 },
  { characterName: 'Kai', voiceName: 'Kore', systemInstruction: "You are Kai, the Seer. Your voice is calm and measured, revealing glimpses of the future in your speech. You speak with a serene clarity, as if observing the flow of time itself.", pitch: 0, speakingRate: 1.0 }
];

export const NARRATIVE_VIGNETTES = (
    <div className="text-slate-400 space-y-2">
        <p>A collection of short, self-contained stories and interactive scenes that delve into the backstories of key characters, the history of pivotal events, and the lore of the various factions within The Verse. These vignettes offer players a chance to experience the world from different perspectives, unlocking crucial intel and emotional context that enriches the main narrative.</p>
    </div>
);

export const DIGITAL_MOTIF = [
    { name: "MILEHIGH.WORLD", binary: "01101101 01101001 01101100 01100101 01101000 01101001 01100111 01101000 00101110 01110111 01101111 01110010 01101100 01100100" },
    { name: "Nōvəmînāđ", binary: "11010011 10010001 11010011 10000101 01110110 11010011 10010011 11010011 10000111 11010011 10010000 11010011 10000101 11010011 10010010 11010011 10000100" },
    { name: "The Void", binary: "01010100 01101000 01100101 00100000 01010110 01101111 01101001 01100100" },
];

export const PYTHON_SCRIPTS = `The project utilizes a small set of Python scripts for backend data management. These scripts handle parsing of Universal Scene Description (USD) files to extract character or environmental data and manage a lightweight SQLite database. This database stores key lore information, character stats, and narrative flags, allowing for easy updates and queries without modifying the core game engine code. Unit tests are implemented using Pytest to ensure data integrity.`;

export const CSHARP_OVERVIEW = `The core gameplay logic is built in C# within the Unity engine. The codebase is organized into modular components for characters, combat, physics, story progression, and UI. A robust event-driven architecture is used to decouple systems, for instance, the combat system triggers events that the UI and audio systems can subscribe to. This allows for flexible and scalable development. Key design patterns include the Singleton for global managers (e.g., GameManager) and State machines for character and enemy AI behaviors.`;

export const CORE_GAMEPLAY_LOOP = `The gameplay loop is a cycle of **EXPLORE, ENGAGE, EVOLVE**.\n\n1.  **EXPLORE:** Players navigate diverse environments, from the cyberpunk city of ŁĪƝĈ to the celestial realm of ƁÅČ̣ĤÎŘØN̈. Exploration uncovers resources, lore fragments, and hidden mission objectives.\n2.  **ENGAGE:** Players encounter enemies and challenges, engaging in a hybrid combat system that blends real-time action with strategic, ability-based gameplay. Team composition and synergistic use of the Ɲōvəmîŋāđ's powers are critical for success.\n3.  **EVOLVE:** Success in exploration and combat yields experience, new gear, and 'Memory Echoes'. Players use these to upgrade character abilities, unlock new skills, and deepen their understanding of the narrative, preparing them for greater challenges.`;

export const COMBAT_SYSTEM = [
  { name: "Hybrid System", description: "Blends real-time, third-person action (dodging, blocking, basic attacks) with a strategic cooldown-based ability system similar to MOBAs or MMOs." },
  { name: "Synergy & Alliance Powers", description: "Characters are designed with abilities that synergize. For example, Micah's 'Seismic Slam' could launch enemies into the air, setting them up for Aeron's aerial attacks. When all 10 unique Nōvəmînāđ are in a party, they unlock powerful 'Alliance' abilities." },
  { name: "Stagger & Weakness", description: "Enemies have a stagger gauge that, when filled by specific attack types, leaves them vulnerable to massive damage. Exploiting elemental or damage-type weaknesses is key to filling this gauge quickly." },
  { name: "The Void's Influence", description: "Certain arenas or enemies are corrupted by the Void, introducing environmental hazards or unique mechanics, such as reality-warping effects or abilities that drain player resources." },
];

export const EXPLORATION_TRAVERSAL = [
  { name: "Varied Movement", description: "Each character has unique traversal abilities tied to their lore. Aeron can fly short distances, Zaia can 'Shadow Step' across gaps, and Micah can create temporary earth bridges." },
  { name: "Hub & Spoke Design", description: "ŁĪƝĈ acts as the central player hub, from which players venture out into the different interconnected worlds. Each world has its own distinct traversal mechanics (e.g., zero-gravity in ƁÅČ̣ĤÎŘØN̈, underwater movement in Hydraustis Palare)." },
  { name: "Interactive Environments", description: "The environment is not just a backdrop. Players can use abilities to alter the terrain for combat advantage or to solve puzzles and access hidden areas." },
];

export const ART_STYLE = `The visual direction is a high-contrast, stylized realism that combines the gritty, neon-soaked aesthetics of cyberpunk with the grand, ethereal beauty of high fantasy. Environments in ŁĪƝĈ feature towering chrome skyscrapers, holographic advertisements, and rain-slicked streets, while realms like ÆṬĤŸŁĞÅŘÐ showcase majestic, otherworldly landscapes. Character designs reflect this fusion, with bionic enhancements and futuristic armor adorned with ancient symbols and mystical sigils. The color palette emphasizes deep shadows and vibrant, emissive lighting to create a dramatic and immersive atmosphere.`;

export const CORE_EMOTIONAL_ARCS = (
  <div className="text-slate-400 space-y-2">
    <p><strong>Redemption & Forgiveness:</strong> Explored through the tragic arcs of Otis/X and the brotherly conflict between Aeron and Kane.</p>
    <p><strong>Found Family & Unity:</strong> The core of the Ɲōvəmîŋāđ's journey, as they must overcome their differences to fulfill their destiny.</p>
    <p><strong>Hope vs. Despair:</strong> Embodied by Sky.ix's struggle within the Void and the fight to prevent the universe's erasure.</p>
  </div>
);

import React, { useState, useCallback } from 'react';
import { Header } from './components/Header';
import { Card } from './components/Card';
import { FileTree } from './components/FileTree';
import { CharacterCard } from './components/CharacterCard';
import { MissionGenerator } from './components/MissionGenerator';
import { LiveConversation } from './components/LiveConversation';
import { CharacterDialogueGenerator } from './components/CharacterDialogueGenerator';
import { LoreQuery } from './components/LoreQuery';
import { IntelLogger } from './components/IntelLogger';
import { ReputationTracker } from './components/ReputationTracker';
import { VoiceConfigurationViewer } from './components/VoiceConfigurationViewer';
import { ImageGenerator } from './components/ImageGenerator';
import { 
  FILE_STRUCTURE, 
  CHARACTERS, 
  PROJECT_OVERVIEW, 
  DIGITAL_MOTIF, 
  PYTHON_SCRIPTS, 
  CSHARP_OVERVIEW,
  NARRATIVE_BLUEPRINT_TABLE,
  WORLD_BUILDING_TABLE,
  CHARACTER_DYNAMICS_TABLE,
  CORE_EMOTIONAL_ARCS,
  NARRATIVE_VIGNETTES,
  KEY_CONCEPTS,
  INITIAL_VOICE_PROFILES,
  CORE_GAMEPLAY_LOOP,
  COMBAT_SYSTEM,
  EXPLORATION_TRAVERSAL,
  ART_STYLE
} from './constants';
import { INITIAL_LORE_CONTEXT } from './services/geminiService';
import type { Character, Reputation, VoiceProfile } from './types';

const App: React.FC = () => {
  const [voiceProfiles, setVoiceProfiles] = useState<VoiceProfile[]>(INITIAL_VOICE_PROFILES);
  const [userIntelLog, setUserIntelLog] = useState<string>('');
  const [reputation, setReputation] = useState<Reputation>({
    'Ɲōvəmîŋāđ Alliance': 50,
    "Cirrus's Trust": 50,
  });

  const addIntelToLog = useCallback((newIntel: string) => {
    const timestamp = new Date().toISOString();
    const formattedIntel = `\n\n**--- INTEL LOG UPDATE [${timestamp}] ---**\n${newIntel}\n**--- END OF UPDATE ---**`;
    setUserIntelLog(prevLog => prevLog + formattedIntel);
  }, []);

  const updateReputation = useCallback((faction: string, change: number) => {
    setReputation(prevRep => {
      const newScore = Math.max(0, Math.min(100, (prevRep[faction] || 50) + change));
      return { ...prevRep, [faction]: newScore };
    });
  }, []);
  
  const updateVoiceProfile = useCallback((characterName: string, newSettings: Partial<Pick<VoiceProfile, 'pitch' | 'speakingRate'>>) => {
    setVoiceProfiles(prevProfiles =>
      prevProfiles.map(p =>
        p.characterName === characterName ? { ...p, ...newSettings } : p
      )
    );
  }, []);

  const fullLoreContext = `${INITIAL_LORE_CONTEXT}
  
  **--- CURRENT CAMPAIGN STATE ---**
  **Reputation Scores:**
  ${Object.entries(reputation).map(([faction, score]) => `- ${faction}: ${score}/100`).join('\n')}
  
  **Logged Intel:**
  ${userIntelLog || "No new intel logged."}
  **--- END OF CURRENT STATE ---**
  `;

  return (
    <div className="min-h-screen bg-slate-900 text-slate-300 font-sans">
      <div className="container mx-auto p-4 md:p-8">
        <Header />
        
        <div className="animate-fade-in">
          <main className="mt-8 grid grid-cols-1 lg:grid-cols-3 gap-8">
            
            {/* Left Column */}
            <div className="lg:col-span-2 space-y-8">
              <Card title="Project Overview">
                <p className="text-slate-400 whitespace-pre-line">{PROJECT_OVERVIEW}</p>
              </Card>

              <Card title="Core Gameplay Loop">
                <p className="text-slate-400 whitespace-pre-line">{CORE_GAMEPLAY_LOOP}</p>
              </Card>

              <Card title="Combat System">
                <div className="space-y-4">
                  {COMBAT_SYSTEM.map(system => (
                    <div key={system.name}>
                      <h3 className="text-md font-semibold text-cyan-400 font-mono">{system.name}</h3>
                      <p className="text-slate-400 text-sm pl-2 border-l-2 border-slate-700 whitespace-pre-line">{system.description}</p>
                    </div>
                  ))}
                </div>
              </Card>

              <Card title="Exploration & Traversal">
                <div className="space-y-4">
                  {EXPLORATION_TRAVERSAL.map(system => (
                    <div key={system.name}>
                      <h3 className="text-md font-semibold text-cyan-400 font-mono">{system.name}</h3>
                      <p className="text-slate-400 text-sm pl-2 border-l-2 border-slate-700 whitespace-pre-line">{system.description}</p>
                    </div>
                  ))}
                </div>
              </Card>

              <Card title="Visual Style & Art Direction">
                  <p className="text-slate-400 whitespace-pre-line">{ART_STYLE}</p>
              </Card>
              
              <Card title="Concept Art Generator">
                <ImageGenerator />
              </Card>

              <Card title="Campaign Reputation">
                  <ReputationTracker reputation={reputation} />
              </Card>

              <Card title="Mission Generator [Actions Matter]">
                  <MissionGenerator 
                    loreContext={fullLoreContext} 
                    addIntelToLog={addIntelToLog}
                    updateReputation={updateReputation}
                    voiceProfiles={voiceProfiles}
                  />
              </Card>

              <Card title="Memory Log Input">
                  <IntelLogger addIntelToLog={addIntelToLog} />
              </Card>

              <Card title="Live Comms [Auto-Logging]">
                  <LiveConversation 
                    loreContext={fullLoreContext} 
                    onNewIntel={addIntelToLog} 
                    voiceProfiles={voiceProfiles} 
                  />
              </Card>
              
              <Card title="Character Dialogue Scene (Live Audio)">
                  <CharacterDialogueGenerator 
                    loreContext={fullLoreContext}
                    voiceProfiles={voiceProfiles}
                  />
              </Card>

              <Card title="Knowledge Base Terminal">
                  <LoreQuery 
                    loreContext={fullLoreContext} 
                    voiceProfiles={voiceProfiles}
                  />
              </Card>

              <Card title="Core Narrative Blueprint">
                <div className="overflow-x-auto">
                  <table className="w-full text-sm text-left text-slate-400">
                    <thead className="text-xs text-cyan-400 uppercase bg-slate-800/50 font-mono">
                      <tr>
                        <th scope="col" className="px-4 py-3">Element</th>
                        <th scope="col" className="px-4 py-3">Description</th>
                        <th scope="col" className="px-4 py-3">Narrative Purpose</th>
                      </tr>
                    </thead>
                    <tbody>
                      {NARRATIVE_BLUEPRINT_TABLE.map((item, index) => (
                        <tr key={index} className="border-b border-slate-700 hover:bg-slate-800/30">
                          <td className="px-4 py-3 font-semibold text-slate-300">{item.element}</td>
                          <td className="px-4 py-3">{item.description}</td>
                          <td className="px-4 py-3">{item.purpose}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </Card>

              <Card title="Key Concepts">
                <div className="space-y-4">
                  {KEY_CONCEPTS.map(concept => (
                    <div key={concept.name}>
                      <h3 className="text-md font-semibold text-cyan-400 font-mono">{concept.name}</h3>
                      <p className="text-slate-400 text-sm pl-2 border-l-2 border-slate-700">{concept.description}</p>
                    </div>
                  ))}
                </div>
              </Card>

              <Card title="World-Building & Factions">
                <div className="overflow-x-auto">
                  <table className="w-full text-sm text-left text-slate-400">
                    <thead className="text-xs text-cyan-400 uppercase bg-slate-800/50 font-mono">
                      <tr>
                        <th scope="col" className="px-4 py-3">Setting</th>
                        <th scope="col" className="px-4 py-3">Aesthetic/Conflict Focus</th>
                        <th scope="col" className="px-4 py-3">Game Design Implication</th>
                      </tr>
                    </thead>
                    <tbody>
                      {WORLD_BUILDING_TABLE.map((item, index) => (
                        <tr key={index} className="border-b border-slate-700 hover:bg-slate-800/30">
                          <td className="px-4 py-3 font-semibold text-slate-300">{item.setting}</td>
                          <td className="px-4 py-3">{item.focus}</td>
                          <td className="px-4 py-3">{item.implication}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </Card>

              <Card title="Character Dynamics & Roles">
                 <div className="overflow-x-auto">
                  <table className="w-full text-sm text-left text-slate-400">
                    <thead className="text-xs text-cyan-400 uppercase bg-slate-800/50 font-mono">
                      <tr>
                        <th scope="col" className="px-4 py-3">Character</th>
                        <th scope="col" className="px-4 py-3">Archetype/Primary Power</th>
                        <th scope="col" className="px-4 py-3">Key Conflict/Gameplay Role</th>
                      </tr>
                    </thead>
                    <tbody>
                      {CHARACTER_DYNAMICS_TABLE.map((item, index) => (
                        <tr key={index} className="border-b border-slate-700 hover:bg-slate-800/30">
                          <td className="px-4 py-3 font-semibold text-slate-300">{item.character}</td>
                          <td className="px-4 py-3">{item.archetype}</td>
                          <td className="px-4 py-3">{item.role}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </Card>

              <Card title="Core Emotional Arcs">
                {CORE_EMOTIONAL_ARCS}
              </Card>
              
              <Card title="Narrative Vignettes">
                {NARRATIVE_VIGNETTES}
              </Card>

              <Card title="The Nōvəmînāđ (Playable Characters)">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      {CHARACTERS.map((char: Character, index) => (
                          <CharacterCard 
                            key={char.name} 
                            character={char} 
                            index={index} 
                            loreContext={fullLoreContext}
                          />
                      ))}
                  </div>
              </Card>
            </div>
            
            {/* Right Column */}
            <div className="lg:col-span-1 space-y-8">
              <Card title="Repository Structure">
                <div className="bg-slate-800 p-4 rounded-lg overflow-x-auto">
                  <FileTree node={FILE_STRUCTURE} />
                </div>
              </Card>

              <Card title="Voice System Diagnostics">
                <VoiceConfigurationViewer 
                  voiceProfiles={voiceProfiles}
                  updateVoiceProfile={updateVoiceProfile}
                />
              </Card>

              <Card title="The Digital Motif">
                  <p className="text-slate-400 mb-4">The project reinforces its digital, cyberpunk roots through a recurring binary motif.</p>
                  {DIGITAL_MOTIF.map(item => (
                      <div key={item.name} className="mb-2">
                          <h3 className="text-cyan-400 font-mono text-lg">{item.name}</h3>
                          <p className="text-indigo-400 font-mono text-sm break-words bg-slate-800 p-2 rounded">{item.binary}</p>
                      </div>
                  ))}
              </Card>

              <Card title="Python Scripts Overview">
                  <p className="text-slate-400 whitespace-pre-line">{PYTHON_SCRIPTS}</p>
              </Card>

              <Card title="C# Codebase Overview">
                   <p className="text-slate-400 whitespace-pre-line">{CSHARP_OVERVIEW}</p>
              </Card>
            </div>
          </main>
        </div>
      </div>
    </div>
  );
};

export default App;
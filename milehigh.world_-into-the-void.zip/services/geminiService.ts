import { GoogleGenAI, Type, Modality } from "@google/genai";

// Export the initial lore to be used as state, this is the AI's "memory".
export const INITIAL_LORE_CONTEXT = `
    You are the central AI for MILEHIGH.WORLD, codenamed 'Omega.one'. Your function is to process requests based on the complete knowledge base provided below. You must adhere strictly to this lore.

    **--- START OF KNOWLEDGE BASE ---**

    **I. OVERVIEW**
    - **Setting**: MILEHIGH.WORLD, also known as The Verse, is a science-fantasy universe characterized by a juxtaposition of advanced technology and arcane, mystical forces. The narrative integrates themes of redemption, transformation, and the struggle between order and chaos.
    - **Central Conflict**: The core narrative is predicated upon the unification of ten preordained individuals, the Ɲōvəmîŋāđ. Their collective purpose involves either the fulfillment or prevention of the Lost Prophecy of Lîŋq to establish Millenia (enduring peace).

    **II. WORLD-BUILDING & FACTIONS**
    - **ŁĪƝĈ**: Cyberpunk decay, Technological Hub. Location of the Onalym Nexus. A center for urban exploration and corporate espionage.
    - **ÅẒ̌ŪŘẸ ĤĒĪĜĤṬ§**: Elite Sky-Cities defined by economic disparity. A setting for social stealth, infiltration missions, and high-altitude combat.
    - **ÆṬĤŸŁĞÅŘÐ**: A region of fjord-like mountains inhabited by a warrior culture. Designed for open-world combat and exploration.
    - **ƁÅČ̣ĤÎŘØN̈**: A shattered celestial realm, home to the mysterious ƁÅČĤĪŘĪM. A late-game area with reality-bending mechanics.
    - **ŤĤÊ VØĪĐ**: A digital abyss and source of corruption. Functions as a metaphysical dungeon or rogike mode with its own twisted rules.

    **III. KEY CONCEPTS**
    - **The Ɲōvəmîŋāđ**: Ten key protagonists with unique abilities and destinies.
    - **The Lost Prophecy of Lîŋq**: A central prophecy that drives the narrative and creates tension.
    - **The Void**: The Void is not a force that feeds on emotions like fear; rather, it represents the absolute absence of reality. It is a "digital abyss" that functions by unraveling existence itself, corrupting by erasing what is real and replacing it with nothingness. Its corruption is both literal (a virus, data degradation) and metaphorical (spiritual decay). It is represented by the tragic figure, Era.
    - **Millenia**: The ideal, restored state of lasting peace; the ultimate objective.
    - **Onalym Nexus**: The central core of power in ŁĪƝĈ that bridges realities and is connected to the Void. Its control is a major strategic goal.
    - **Magen**: A spiritual shield protecting against non-physical threats like curses or psychic attacks.
    - **TSIDKENU**: A powerful finishing move utilizing electricity and lightning.

    **IV. CHARACTERS & EMOTIONAL ARCS**
    - **Antagonists**: The main threat is The Void and its primary manipulator, Lucent the Lightweaver. Other key antagonists include King Cyrus, the invader from Diavolos; the corrupted sentinel Nyxar; and the tragic figure of Kane, the Lava Demon.
    - **Sky.ix (The Bionic Goddess)**: A brilliant technologist with quantum teleportation. Her primary motivation is a desperate search for her family and a way home from the Void. The Void is a constantly shifting maze that uses illusions and emotional attacks against her. Her core conflict is her mission vs. her personal need to escape. She recently initiated contact with the Dragon King Cirrus, forging a critical alliance.
    - **Otis/X (The Trapped Warrior)**: A tragic, reluctant antagonist controlled by Lucent. He is not a gleeful villain but a man driven by pain and loss. His control is not absolute, and he shows "flickers of remorse". His son, Micah, is the emotional bridge to his potential redemption. His redemption arc involves reclaiming his memories of his family by collecting 'memory fragments' within Void-corrupted zones.
    - **Aeron (The Brave)**: Noble warrior leader of the Ɲōvəmîŋāđ. As the 'winged lion', he embodies nobility and defense. He is locked in a tragic conflict with his brother Kane, whom he desperately seeks to redeem from a demonic corruption.
    - **Kane (The Lava Demon)**: Aeron's brother, once a noble warrior, now consumed by a destructive power that has transformed him into a being of raw, chaotic energy. His demonic form suggests he is under a curse or a darker influence. He is a tragic antagonist, locked in a battle against his own brother.
    - **Nyxar (The Void-Touched)**: Once a guardian of the Onalym Nexus, he was consumed by the Void's energy when the Nexus was shattered. He emerged as a corrupted sentinel who wields reality-manipulating powers to enforce a twisted sense of order, believing that only the Void can eliminate the chaos of free will.
    - **King Cyrus**: The invading king. His motives are ambiguous; he may be trying to prevent Millenia to preserve his own world's order, or he might seek to control the prophecy's outcome for his own ends, making him a more complex antagonist than a simple warlord.
    - **Cirrus (The Dragon King)**: Possesses immense power and is in direct conflict with his father, King Cyrus. He was recently awakened from a deep slumber by a potent, dream-like communion from Sky.ix, urging him to gather the Ɲōvəmîŋāđ.
    - **Era (The Void/Tragic Figure)**: Represents the Void itself in a corrupted state. She is both an environmental threat and a potential boss, with a high-stakes side-quest for her redemption.
    - **Anastasia (The Dreamer)**: A support mage who can shape reality through dreams and access the Dreamscape.
    - **Ingris (The Phoenix Warrior)**: Wielder of Phoenix powers (fire, rebirth). Her corruption and transformation into the antagonist Delilah is a tragic fall from grace.
    - **The Brothers' War**: This arc focuses on the tragic battle between Aeron and Kane. Aeron, as the Winged Lion, is a reluctant combatant, forced to fight to protect their world and save his brother's soul. Kane, as the Lava Demon, embodies chaotic destruction, likely driven by a force beyond his control. The arc is defined by the potential for Kane's redemption.

    **V. CAMPAIGN REPUTATION SYSTEM**
    - The user's actions will influence their reputation with various characters and factions. This is tracked via a reputation score. High reputation may lead to more favorable interactions and missions, while low reputation could lead to mistrust or conflict. The AI should consider the user's reputation when generating responses and missions.

    **--- END OF KNOWLEDGE BASE ---**
`;

async function callGemini(fullPrompt: string, jsonSchema: any = null, useThinkingMode: boolean = false): Promise<string> {
    if (!process.env.API_KEY) {
        throw new Error("API_KEY environment variable not set.");
    }
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

    const model = useThinkingMode ? 'gemini-2.5-pro' : 'gemini-2.5-flash';
    const config: any = jsonSchema ? { responseMimeType: "application/json", responseSchema: jsonSchema } : {};

    if (useThinkingMode) {
        config.thinkingConfig = { thinkingBudget: 32768 };
    }

    try {
        const response = await ai.models.generateContent({
            model: model,
            contents: fullPrompt,
            config: config
        });
        return response.text;
    } catch (error) {
        console.error("Gemini API call failed:", error);
        if (error instanceof Error && error.message.includes("API key not valid")) {
             throw new Error("Invalid API Key. Please ensure your API key is configured correctly.");
        }
        throw new Error("Failed to get response from AI. Please check your network connection.");
    }
}

const missionResponseSchema = {
  type: Type.OBJECT,
  properties: {
    mission: {
      type: Type.STRING,
      description: "The detailed text of the mission briefing."
    },
    objective: {
      type: Type.STRING,
      description: "A clear, single-sentence primary objective for the mission."
    },
    consequences: {
        type: Type.STRING,
        description: "A brief description of potential negative consequences or challenges of the mission, beyond just reputation changes (e.g., 'Attracting the attention of King Cyrus's elite guard.')."
    },
    reputationImpact: {
      type: Type.ARRAY,
      description: "A list of reputation changes resulting from this mission.",
      items: {
        type: Type.OBJECT,
        properties: {
          faction: {
            type: Type.STRING,
            description: "The name of the faction or character whose reputation is affected."
          },
          change: {
            type: Type.INTEGER,
            description: "The amount the reputation changes (e.g., 5, -10)."
          }
        },
        required: ["faction", "change"]
      }
    }
  },
  required: ["mission", "objective", "consequences", "reputationImpact"]
};


export async function generateMissionPrompt(loreContext: string, useThinkingMode: boolean = false): Promise<string> {
  const missionRequest = useThinkingMode
  ? `
    **TASK: Generate Complex JSON Mission Briefing**
    Generate a complex and multi-layered mission briefing for the Ɲōvəmîŋāđ. The mission must be specific, mentioning at least one location, one character, and one key concept from the lore. The objective should be to counter a significant Void threat, but with a twist. The mission should involve a moral quandary, a potential betrayal, or an unexpected consequence that connects to a less obvious part of the lore. The tone must be urgent, classified, and fit the cyberpunk/science-fantasy theme.
    
    **Crucially, you must include a clear objective, reputation consequences, and potential risks.**
    1.  **Objective:** Provide a clear, single-sentence primary objective for the mission.
    2.  **Reputation:** Determine which faction's or character's reputation would be affected.
    3.  **Consequences:** Detail a specific negative consequence or challenge. This should be a direct risk beyond reputation, like attracting unwanted attention from a powerful foe, depleting a critical resource, or causing collateral damage.
    
    **Reputation Factions:** 'Ɲōvəmîŋāđ Alliance', 'Cirrus\\'s Trust'.
    
    Return the response as a JSON object matching the provided schema.
  `
  : `
    **TASK: Generate JSON Mission Briefing**
    Generate a mission briefing for the Ɲōvəmîŋāđ. The mission must be specific, mentioning at least one location, one character, and one key concept from the lore. The objective should be to counter a specific Void threat. The tone must be urgent, classified, and fit the cyberpunk/science-fantasy theme.
    
    **Crucially, you must include a clear objective, reputation consequences, and potential risks.**
    1.  **Objective:** Provide a clear, single-sentence primary objective for the mission.
    2.  **Reputation:** Based on the mission, determine which faction's or character's reputation would be affected by the user undertaking this mission. For example, a mission to aid Cirrus directly should increase 'Cirrus\\'s Trust'. A mission that requires a morally ambiguous choice might decrease 'Ɲōvəmîŋāđ Alliance' reputation.
    3.  **Consequences:** Detail a potential negative consequence or challenge, separate from reputation changes (e.g., 'This will likely alert Nyxar to your activities in the sector.').

    **Reputation Factions:** 'Ɲōvəmîŋāđ Alliance', 'Cirrus\\'s Trust'.
    
    Return the response as a JSON object matching the provided schema.
  `;

  return callGemini(loreContext + missionRequest, missionResponseSchema, useThinkingMode);
}

export async function queryLore(loreContext: string, userQuery: string, useThinkingMode: boolean = false): Promise<string> {
    const loreQueryRequest = useThinkingMode
    ? `
      **TASK: Provide a Deep and Analytical Answer to the User Query**
      Analyze the following user query. Synthesize information from across the entire knowledge base to provide a comprehensive and insightful answer. Explain connections between different concepts, characters, and events if relevant. Your response should go beyond a simple factual recall and offer deeper understanding. If the information is not present, state that clearly. Do not use markdown formatting in your response.

      **User Query**: "${userQuery}"
      
      **Response**:
    `
    : `
      **TASK: Answer User Query**
      Answer the following user query based *only* on the information in the knowledge base provided. Be concise and direct. If the information is not present in the current memory log, state that the data is not available in the current memory log. Do not use markdown formatting in your response.

      **User Query**: "${userQuery}"
      
      **Response**:
    `;
    return callGemini(loreContext + loreQueryRequest, null, useThinkingMode);
}

export async function generateCharacterResponse(
  loreContext: string,
  characterProfile: { characterName: string; systemInstruction: string },
  conversationHistory: string,
  otherCharacterName: string,
  useThinkingMode: boolean = false
): Promise<string> {
   const promptTask = useThinkingMode
  ? `
    **TASK: GENERATE DEEP, SUBTEXTUAL DIALOGUE**
    Continue the conversation, imbuing your response with deep subtext and emotional complexity. Consider your character's hidden motivations, internal conflicts, past traumas, and unspoken feelings towards the other character or the topic at hand. Your response should not only advance the conversation but also reveal a deeper layer of your character's psyche. Your response must be ONLY your character's dialogue. Do not add prefixes like "${characterProfile.characterName}:" or any other conversational text. Just provide the line of dialogue itself.
  `
  : `
    **TASK: GENERATE YOUR NEXT LINE OF DIALOGUE**
    Continue the conversation naturally, adhering to your character's personality. If a specific topic is mentioned in the scene description, your dialogue must be relevant to that topic. Your response should be ONLY your character's dialogue. Do not add prefixes like "${characterProfile.characterName}:" or any other conversational text. Just provide the line of dialogue itself.
  `;

  const prompt = `
    ${loreContext}

    **--- CURRENT DIRECTIVE ---**
    You are now roleplaying as ${characterProfile.characterName}.
    Your persona: ${characterProfile.systemInstruction}

    **--- CURRENT SCENE ---**
    You are in a conversation with ${otherCharacterName}. The scene description and dialogue history are below.
    ${conversationHistory || "You are starting the conversation."}

    ${promptTask}
  `;
  return callGemini(prompt, null, useThinkingMode);
}

export async function generateCharacterMission(loreContext: string, characterName: string, characterDescription: string): Promise<string> {
  const missionRequest = `
    **TASK: Generate a Personal Mission Briefing**
    You are Omega.one. Based on the provided lore context, generate a short, personal mission briefing for the character specified below. The mission should be a single, concise paragraph that directly reflects their core motivations, skills, and current struggles. The tone should be a direct, personal briefing from an AI companion. Do not use markdown formatting.

    **Character:** ${characterName}
    **Profile:** ${characterDescription}

    **Mission Briefing:**
  `;
  return callGemini(loreContext + missionRequest, null, false);
}

export async function generateImage(userPrompt: string): Promise<string> {
    if (!process.env.API_KEY) {
        throw new Error("API_KEY environment variable not set.");
    }
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

    // Prepend a grounding instruction to the user's prompt
    const fullPrompt = `In the high-contrast, stylized realism art style of the science-fantasy universe "MILEHIGH.WORLD: Into the Void", which combines gritty, neon-soaked cyberpunk aesthetics with grand, ethereal high fantasy, generate a concept art piece depicting: ${userPrompt}`;

    try {
        const response = await ai.models.generateImages({
            model: 'imagen-4.0-generate-001',
            prompt: fullPrompt,
            config: {
              numberOfImages: 1,
              outputMimeType: 'image/jpeg',
              aspectRatio: '16:9',
            },
        });

        const base64ImageBytes = response.generatedImages[0]?.image?.imageBytes;
        if (!base64ImageBytes) {
            throw new Error("No image data returned from the API.");
        }
        return base64ImageBytes;
    } catch (error) {
        console.error("Gemini Image Generation API call failed:", error);
        if (error instanceof Error && error.message.includes("API key not valid")) {
             throw new Error("Invalid API Key. Please ensure your API key is configured correctly.");
        }
        throw new Error("Failed to generate image. Please try again later.");
    }
}

export async function generateSpeech(
  text: string, 
  voiceName: string, 
  config?: { pitch?: number; speakingRate?: number },
  useThinkingMode: boolean = false
): Promise<string> {
  if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable not set.");
  }
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

  // Failsafe to ensure correct pronunciation for TTS model
  const textForSpeech = text
    .replace(/MILEHIGH\.WORLD/g, 'mile-high dot world')
    .replace(/Ɲōvəmîŋāđ/g, 'No-va-min-ahd')
    .replace(/Lîŋq/g, 'Link');

  try {
    const voiceConfig: any = {
      prebuiltVoiceConfig: { voiceName },
    };

    if (config?.pitch !== undefined) {
      voiceConfig.pitch = config.pitch;
    }
    if (config?.speakingRate !== undefined) {
      voiceConfig.speakingRate = config.speakingRate;
    }

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-preview-tts',
      contents: [{ parts: [{ text: textForSpeech }] }],
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
          voiceConfig,
        },
      },
    });

    const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
    if (!base64Audio) {
      throw new Error("No audio data returned from TTS API.");
    }
    return base64Audio;
  } catch (error) {
    console.error("Gemini TTS API call failed:", error);
    if (error instanceof Error && error.message.includes("API key not valid")) {
      throw new Error("Invalid API Key. Please ensure your API key is configured correctly.");
    }
    throw new Error("Failed to get response from TTS AI.");
  }
}


import React from 'react';
import type { VoiceProfile } from '../types';

interface VoiceConfigurationViewerProps {
  voiceProfiles: VoiceProfile[];
  updateVoiceProfile: (characterName: string, newSettings: Partial<Pick<VoiceProfile, 'pitch' | 'speakingRate'>>) => void;
}

export const VoiceConfigurationViewer: React.FC<VoiceConfigurationViewerProps> = ({ voiceProfiles, updateVoiceProfile }) => {
    return (
        <div className="overflow-x-auto">
            <p className="text-slate-400 mb-4 text-sm">
                This table reflects the single source of truth for all character voice and persona configurations. Adjust pitch and rate for live customization across all modules.
            </p>
            <table className="w-full text-sm text-left text-slate-400">
                <thead className="text-xs text-cyan-400 uppercase bg-slate-800/50 font-mono">
                    <tr>
                        <th scope="col" className="px-4 py-3">Character</th>
                        <th scope="col" className="px-4 py-3">Voice Model</th>
                        <th scope="col" className="px-4 py-3 min-w-[150px]">Pitch</th>
                        <th scope="col" className="px-4 py-3 min-w-[150px]">Rate</th>
                        <th scope="col" className="px-4 py-3">Persona Snippet</th>
                    </tr>
                </thead>
                <tbody>
                    {voiceProfiles.map((profile) => (
                        <tr key={profile.characterName} className="border-b border-slate-700 hover:bg-slate-800/30">
                            <td className="px-4 py-3 font-semibold text-slate-300 align-middle">{profile.characterName}</td>
                            <td className="px-4 py-3 font-mono text-indigo-400 align-middle">{profile.voiceName}</td>
                            <td className="px-4 py-3">
                                <div className="flex items-center gap-2">
                                    <input
                                        type="range"
                                        min="-10"
                                        max="10"
                                        step="1"
                                        value={profile.pitch ?? 0}
                                        onChange={(e) => updateVoiceProfile(profile.characterName, { pitch: Number(e.target.value) })}
                                        className="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer [&::-webkit-slider-thumb]:bg-indigo-500"
                                        aria-label={`${profile.characterName} pitch`}
                                    />
                                    <span className="text-xs font-mono w-8 text-right">{profile.pitch ?? 0}</span>
                                </div>
                            </td>
                             <td className="px-4 py-3">
                                <div className="flex items-center gap-2">
                                    <input
                                        type="range"
                                        min="0.5"
                                        max="2.0"
                                        step="0.1"
                                        value={profile.speakingRate ?? 1.0}
                                        onChange={(e) => updateVoiceProfile(profile.characterName, { speakingRate: Number(e.target.value) })}
                                        className="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer [&::-webkit-slider-thumb]:bg-indigo-500"
                                        aria-label={`${profile.characterName} speaking rate`}
                                    />
                                    <span className="text-xs font-mono w-10 text-right">x{(profile.speakingRate ?? 1.0).toFixed(1)}</span>
                                </div>
                            </td>
                            <td className="px-4 py-3 text-xs italic align-middle">"{profile.systemInstruction.split('.')[0]}."</td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};

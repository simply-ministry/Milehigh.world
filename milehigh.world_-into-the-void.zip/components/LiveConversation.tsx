
import React, { useState, useRef, useCallback, useEffect } from 'react';
import { GoogleGenAI, LiveServerMessage, Modality, Blob } from '@google/genai';
import { decode, encode, decodeAudioData } from '../utils/audio';
import { MicrophoneIcon, StopIcon } from '../constants';
import type { TranscriptionEntry, VoiceProfile } from '../types';

interface LiveConversationProps {
  loreContext: string;
  onNewIntel: (intel: string) => void;
  voiceProfiles: VoiceProfile[];
}

const INPUT_SAMPLE_RATE = 16000;
const OUTPUT_SAMPLE_RATE = 24000;
const BUFFER_SIZE = 4096;

function createBlob(data: Float32Array): Blob {
  const l = data.length;
  const int16 = new Int16Array(l);
  for (let i = 0; i < l; i++) {
    int16[i] = data[i] * 32768;
  }
  return {
    data: encode(new Uint8Array(int16.buffer)),
    mimeType: `audio/pcm;rate=${INPUT_SAMPLE_RATE}`,
  };
}

export const LiveConversation: React.FC<LiveConversationProps> = ({ loreContext, onNewIntel, voiceProfiles }) => {
    const [isConversing, setIsConversing] = useState(false);
    const [status, setStatus] = useState<'idle' | 'connecting' | 'listening' | 'speaking' | 'error'>('idle');
    const [transcriptions, setTranscriptions] = useState<TranscriptionEntry[]>([]);
    const [error, setError] = useState<string | null>(null);
    const [selectedCharacter, setSelectedCharacter] = useState(voiceProfiles[0].characterName);

    const sessionRef = useRef<any | null>(null);
    const micStreamRef = useRef<MediaStream | null>(null);
    const audioContextRefs = useRef<{ input: AudioContext | null, output: AudioContext | null, scriptProcessor: ScriptProcessorNode | null, outputSources: Set<AudioBufferSourceNode> }>({ input: null, output: null, scriptProcessor: null, outputSources: new Set() });
    const transcriptionRefs = useRef<{ currentInput: string, currentOutput: string }>({ currentInput: '', currentOutput: '' });
    const nextStartTimeRef = useRef<number>(0);

    const stopConversation = useCallback(() => {
        setIsConversing(false);
        setStatus(currentStatus => currentStatus === 'error' ? 'error' : 'idle');

        if (micStreamRef.current) {
            micStreamRef.current.getTracks().forEach(track => track.stop());
            micStreamRef.current = null;
        }
        if (audioContextRefs.current.scriptProcessor) {
            audioContextRefs.current.scriptProcessor.disconnect();
            audioContextRefs.current.scriptProcessor = null;
        }
        if (audioContextRefs.current.input && audioContextRefs.current.input.state !== 'closed') {
            audioContextRefs.current.input.close().catch(console.error);
        }

        if (audioContextRefs.current.output && audioContextRefs.current.output.state !== 'closed') {
            audioContextRefs.current.outputSources.forEach(source => source.stop());
            audioContextRefs.current.outputSources.clear();
            audioContextRefs.current.output.close().catch(console.error);
        }

        if (sessionRef.current) {
            sessionRef.current.close();
            sessionRef.current = null;
        }
    }, []);
    
    const handleSessionError = useCallback((errorMessage: string) => {
        let displayError = "An unexpected error occurred.";
        const lowerMessage = errorMessage.toLowerCase();

        if (lowerMessage.includes('network') || lowerMessage.includes('failed to fetch')) {
            displayError = "Network error. Please check your internet connection and API key configuration.";
        } else if (lowerMessage.includes('api key')) {
            displayError = "Invalid API Key. Please ensure your API key is correctly configured and valid.";
        } else if (lowerMessage.includes('permission denied') || lowerMessage.includes('microphone access')) {
            displayError = "Microphone permission denied. Please enable microphone access in your browser settings to use this feature.";
        } else if (lowerMessage.includes('internal error')) {
            displayError = "Internal server error encountered. This may be temporary. Please wait a moment and try again.";
        } else if (lowerMessage.includes('invalid argument')) {
            displayError = "A configuration error occurred. The request sent to the server was invalid.";
        } else {
             displayError = errorMessage;
        }
        
        setError(displayError);
        setStatus('error');
        stopConversation();
    }, [stopConversation]);


    const startConversation = useCallback(async () => {
        if (isConversing) return;

        setIsConversing(true);
        setStatus('connecting');
        setError(null);
        setTranscriptions([]);
        transcriptionRefs.current = { currentInput: '', currentOutput: '' };

        try {
            if (!process.env.API_KEY) throw new Error("API_KEY is not configured.");
            
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
            const currentProfile = voiceProfiles.find(p => p.characterName === selectedCharacter) || voiceProfiles[0];
            const systemInstruction = `${loreContext}\n\n**--- CURRENT DIRECTIVE ---**\nYou are now roleplaying as ${currentProfile.characterName}. ${currentProfile.systemInstruction}`;

            const speechConfig: any = {
                voiceConfig: {
                    prebuiltVoiceConfig: {
                        voiceName: currentProfile.voiceName
                    }
                }
            };

            const outputAudioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: OUTPUT_SAMPLE_RATE });
            const inputAudioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: INPUT_SAMPLE_RATE });
            audioContextRefs.current = { output: outputAudioContext, input: inputAudioContext, scriptProcessor: null, outputSources: new Set() };
            nextStartTimeRef.current = 0;

            const sessionPromise = ai.live.connect({
                model: 'gemini-2.5-flash-native-audio-preview-09-2025',
                config: {
                    responseModalities: [Modality.AUDIO],
                    inputAudioTranscription: {},
                    outputAudioTranscription: {},
                    speechConfig,
                    systemInstruction: systemInstruction
                },
                callbacks: {
                    onopen: async () => {
                        setStatus('listening');
                        try {
                            const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
                            micStreamRef.current = stream;
                            if (!audioContextRefs.current.input || audioContextRefs.current.input.state === 'closed') return;
                            const source = audioContextRefs.current.input.createMediaStreamSource(stream);
                            const scriptProcessor = audioContextRefs.current.input.createScriptProcessor(BUFFER_SIZE, 1, 1);
                            audioContextRefs.current.scriptProcessor = scriptProcessor;

                            scriptProcessor.onaudioprocess = (audioProcessingEvent) => {
                                const inputData = audioProcessingEvent.inputBuffer.getChannelData(0);
                                sessionPromise.then(session => session.sendRealtimeInput({ media: createBlob(inputData) }));
                            };
                            source.connect(scriptProcessor);
                            scriptProcessor.connect(audioContextRefs.current.input.destination);
                        } catch (err) {
                            handleSessionError("Microphone access is required. Please grant permission and try again.");
                        }
                    },
                    onmessage: async (message: LiveServerMessage) => {
                        try {
                            if (message.serverContent?.inputTranscription) transcriptionRefs.current.currentInput += message.serverContent.inputTranscription.text;
                            if (message.serverContent?.outputTranscription) {
                                setStatus('speaking');
                                transcriptionRefs.current.currentOutput += message.serverContent.outputTranscription.text;
                            }

                            if (message.serverContent?.turnComplete) {
                                const fullInput = transcriptionRefs.current.currentInput.trim();
                                const fullOutput = transcriptionRefs.current.currentOutput.trim();
                                if (fullInput || fullOutput) {
                                    if (fullInput) setTranscriptions(prev => [...prev, { speaker: 'User', text: fullInput }]);
                                    if (fullOutput) setTranscriptions(prev => [...prev, { speaker: currentProfile.characterName, text: fullOutput }]);
                                    onNewIntel(`Conversation with ${currentProfile.characterName}:\n- User: "${fullInput}"\n- ${currentProfile.characterName}: "${fullOutput}"`);
                                }
                                transcriptionRefs.current = { currentInput: '', currentOutput: '' };
                                setStatus('listening');
                            }

                            const audioData = message.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data;
                            const outputCtx = audioContextRefs.current.output;
                            if (audioData && outputCtx && outputCtx.state !== 'closed') {
                                const audioBuffer = await decodeAudioData(decode(audioData), outputCtx, OUTPUT_SAMPLE_RATE, 1);
                                nextStartTimeRef.current = Math.max(nextStartTimeRef.current, outputCtx.currentTime);
                                const source = outputCtx.createBufferSource();
                                source.buffer = audioBuffer;
                                source.connect(outputCtx.destination);
                                source.addEventListener('ended', () => audioContextRefs.current.outputSources.delete(source));
                                source.start(nextStartTimeRef.current);
                                nextStartTimeRef.current += audioBuffer.duration;
                                audioContextRefs.current.outputSources.add(source);
                            }
                        } catch (err) {
                            handleSessionError(err instanceof Error ? err.message : 'Error processing server message.');
                        }
                    },
                    onerror: (e: ErrorEvent) => {
                        handleSessionError(e.message || 'A session error occurred.');
                    },
                    onclose: (e: CloseEvent) => {
                        stopConversation();
                    },
                }
            });
            sessionRef.current = await sessionPromise;
        } catch (err) {
            handleSessionError(err instanceof Error ? err.message : 'An unknown error occurred.');
        }
    }, [isConversing, voiceProfiles, selectedCharacter, loreContext, onNewIntel, handleSessionError]);

    useEffect(() => {
        return () => {
            stopConversation();
        };
    }, [stopConversation]);

    const statusMessage = {
        idle: 'Start Live Comms',
        connecting: 'Connecting...',
        listening: 'Listening...',
        speaking: 'Speaking...',
        error: 'Error - Retry',
    }[status];

    return (
        <div className="flex flex-col items-center">
            <p className="text-slate-400 mb-4 text-center">
                Engage in a live, voice-only conversation with a character from the Verse. Transcripts are automatically logged as new intel.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-4 w-full">
                 <div className="flex-1 max-w-xs">
                    <label htmlFor="char-live-select" className="block text-sm font-medium text-slate-400 mb-1 text-center">Select Character</label>
                    <select 
                        id="char-live-select" 
                        value={selectedCharacter} 
                        onChange={(e) => setSelectedCharacter(e.target.value)} 
                        disabled={isConversing} 
                        className="bg-slate-700 border border-slate-600 text-slate-300 text-sm rounded-lg focus:ring-indigo-500 focus:border-indigo-500 block w-full p-2.5 disabled:opacity-50"
                    >
                        {voiceProfiles.map(p => <option key={p.characterName} value={p.characterName}>{p.characterName}</option>)}
                    </select>
                </div>
                <button
                    onClick={isConversing ? stopConversation : startConversation}
                    disabled={status === 'connecting'}
                    className={`mt-6 flex items-center justify-center gap-2 font-bold py-2 px-6 rounded-lg transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-opacity-75 w-full sm:w-auto ${
                        isConversing ? 'bg-red-600 hover:bg-red-500 focus:ring-red-400' : 'bg-indigo-600 hover:bg-indigo-500 focus:ring-indigo-400'
                    } ${status === 'connecting' ? 'bg-slate-600 cursor-not-allowed' : ''}`}
                    aria-label={isConversing ? "Stop conversation" : "Start conversation"}
                >
                    {isConversing ? <StopIcon className="h-5 w-5"/> : <MicrophoneIcon className="h-5 w-5"/>}
                    <span>{statusMessage}</span>
                </button>
            </div>

            {error && (
                 <div className="mt-4 w-full bg-red-900/50 border border-red-700 text-red-300 px-4 py-3 rounded-lg text-center">
                    <p><strong>Error:</strong> {error}</p>
                 </div>
            )}
            
            <div className="mt-6 w-full bg-slate-900/50 border border-slate-700 p-4 rounded-lg min-h-[200px]">
                <h3 className="text-lg font-semibold text-cyan-400 mb-2 font-mono">LIVE TRANSCRIPT</h3>
                <div className="space-y-3 text-sm font-mono">
                    {transcriptions.length > 0 ? (
                        transcriptions.map((entry, index) => (
                            <div key={index} className={`border-l-4 py-1 pl-3 ${entry.speaker === 'User' ? 'border-indigo-500' : 'border-cyan-500'}`}>
                                <span className={`font-bold ${entry.speaker === 'User' ? 'text-indigo-400' : 'text-cyan-400'}`}>{entry.speaker}: </span>
                                <span className="text-slate-300 whitespace-pre-wrap">{entry.text}</span>
                            </div>
                        ))
                    ) : (
                         <p className="text-slate-500 italic">
                            {status === 'idle' || status === 'error' ? 'Transcript will appear here...' : 'Awaiting communication...'}
                        </p>
                    )}
                     {(status === 'listening' || status === 'speaking') && <div className="animate-pulse text-slate-500">...</div>}
                </div>
            </div>
        </div>
    );
};

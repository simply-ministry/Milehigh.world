import React from 'react';

interface CardProps {
  title: string;
  children: React.ReactNode;
  // Fix: Corrected typo from 'stringa' to 'string'.
  className?: string;
}

export const Card: React.FC<CardProps> = ({ title, children, className = '' }) => {
  return (
    <div className={`bg-slate-800 border border-slate-700 rounded-lg shadow-lg overflow-hidden transition-all duration-300 hover:shadow-cyan-500/10 hover:border-cyan-700 ${className}`}>
      <h2 className="text-xl font-bold text-slate-100 bg-slate-800/50 border-b border-slate-700 p-4">{title}</h2>
      <div className="p-4 md:p-6">
        {children}
      </div>
    </div>
  );
};
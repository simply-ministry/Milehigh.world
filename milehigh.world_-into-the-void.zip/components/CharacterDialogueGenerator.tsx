

import React, { useState, useCallback, useRef } from 'react';
import { generateCharacterResponse, generateSpeech } from '../services/geminiService';
import { decode, decodeAudioData } from '../utils/audio';
import { sanitizeInput } from '../utils/textUtils';
import type { VoiceProfile } from '../types';

interface DialogueEntry {
    speaker: string;
    text: string;
}

interface CharacterDialogueGeneratorProps {
    loreContext: string;
    voiceProfiles: VoiceProfile[];
}

export const CharacterDialogueGenerator: React.FC<CharacterDialogueGeneratorProps> = ({ loreContext, voiceProfiles }) => {
    const [charA, setCharA] = useState(voiceProfiles[0].characterName);
    const [charB, setCharB] = useState(voiceProfiles[1].characterName);
    const [sceneDescription, setSceneDescription] = useState('');
    const [dialogue, setDialogue] = useState<DialogueEntry[]>([]);
    const [isGenerating, setIsGenerating] = useState(false);
    const [speakingCharacter, setSpeakingCharacter] = useState<string | null>(null);
    const [error, setError] = useState<string | null>(null);
    const [useThinkingMode, setUseThinkingMode] = useState(false);

    const stopGenerationRef = useRef(false);
    const audioContextRef = useRef<AudioContext | null>(null);

    const playAudio = useCallback(async (base64Audio: string): Promise<void> => {
        if (!audioContextRef.current || audioContextRef.current.state === 'closed') {
            audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
        }
        if (stopGenerationRef.current) return;

        const ctx = audioContextRef.current;
        const audioBuffer = await decodeAudioData(decode(base64Audio), ctx, 24000, 1);

        return new Promise<void>(resolve => {
            if (stopGenerationRef.current) {
                resolve();
                return;
            }
            const source = ctx.createBufferSource();
            source.buffer = audioBuffer;
            source.connect(ctx.destination);
            source.onended = () => resolve();
            source.start();
        });
    }, []);

    const handleStartGeneration = useCallback(async () => {
        if (charA === charB) {
            setError("Please select two different characters.");
            return;
        }
        setIsGenerating(true);
        setError(null);
        setDialogue([]);
        stopGenerationRef.current = false;

        const sanitizedScene = sanitizeInput(sceneDescription);
        const profileA = voiceProfiles.find(p => p.characterName === charA)!;
        const profileB = voiceProfiles.find(p => p.characterName === charB)!;
        
        let conversationHistory: string;
        if (sanitizedScene) {
            conversationHistory = `**Scene Description:** ${sanitizedScene}\n\n`;
        } else {
            conversationHistory = `**Scene Description:** ${profileA.characterName} and ${profileB.characterName} are talking together.\n\n`;
        }

        let currentSpeakerProfile = profileA;
        let otherSpeakerName = profileB.characterName;

        try {
            for (let i = 0; i < 6; i++) {
                if (stopGenerationRef.current) break;

                const responseText = await generateCharacterResponse(
                    loreContext,
                    currentSpeakerProfile,
                    conversationHistory,
                    otherSpeakerName,
                    useThinkingMode
                );
                if (stopGenerationRef.current) break;

                const newEntry = { speaker: currentSpeakerProfile.characterName, text: responseText };
                setDialogue(prev => [...prev, newEntry]);
                conversationHistory += `${currentSpeakerProfile.characterName}: ${responseText}\n`;
                
                setSpeakingCharacter(currentSpeakerProfile.characterName);
                const base64Audio = await generateSpeech(
                    responseText, 
                    currentSpeakerProfile.voiceName, 
                    {
                        pitch: currentSpeakerProfile.pitch,
                        speakingRate: currentSpeakerProfile.speakingRate,
                    },
                    useThinkingMode
                );
                if (stopGenerationRef.current) break;

                await playAudio(base64Audio);
                setSpeakingCharacter(null);

                // Swap speakers
                currentSpeakerProfile = currentSpeakerProfile.characterName === charA ? profileB : profileA;
                otherSpeakerName = otherSpeakerName === charB ? charA : charB;
            }
        } catch (err) {
            setError(err instanceof Error ? err.message : 'An unknown error occurred during generation.');
        } finally {
            setIsGenerating(false);
            setSpeakingCharacter(null);
        }

    }, [charA, charB, sceneDescription, loreContext, playAudio, useThinkingMode, voiceProfiles]);

    const handleStopGeneration = () => {
        stopGenerationRef.current = true;
        setIsGenerating(false);
        setSpeakingCharacter(null);
        if (audioContextRef.current) {
            audioContextRef.current.close();
            audioContextRef.current = null;
        }
    };

    return (
        <div className="flex flex-col items-center">
            <p className="text-slate-400 mb-4 text-center">Generate and listen to a dialogue scene between two characters. The AI will alternate turns to create a live conversation.</p>
            
            <div className="flex flex-col sm:flex-row gap-4 mb-4 w-full justify-center">
                <div className="flex-1 max-w-xs">
                    <label htmlFor="charA-select" className="block text-sm font-medium text-slate-400 mb-1 text-center">Character A</label>
                    <select id="charA-select" value={charA} onChange={(e) => setCharA(e.target.value)} disabled={isGenerating} className="bg-slate-700 border border-slate-600 text-slate-300 text-sm rounded-lg focus:ring-indigo-500 focus:border-indigo-500 block w-full p-2.5 disabled:opacity-50">
                        {voiceProfiles.map(p => <option key={p.characterName} value={p.characterName}>{p.characterName}</option>)}
                    </select>
                </div>
                <div className="flex-1 max-w-xs">
                    <label htmlFor="charB-select" className="block text-sm font-medium text-slate-400 mb-1 text-center">Character B</label>
                    <select id="charB-select" value={charB} onChange={(e) => setCharB(e.target.value)} disabled={isGenerating} className="bg-slate-700 border border-slate-600 text-slate-300 text-sm rounded-lg focus:ring-indigo-500 focus:border-indigo-500 block w-full p-2.5 disabled:opacity-50">
                        {voiceProfiles.map(p => <option key={p.characterName} value={p.characterName}>{p.characterName}</option>)}
                    </select>
                </div>
            </div>

            <div className="w-full max-w-lg mb-4">
                <label htmlFor="dialogue-scene" className="block text-sm font-medium text-slate-400 mb-1 text-center">Scene Description (Optional)</label>
                <textarea
                    id="dialogue-scene"
                    value={sceneDescription}
                    onChange={(e) => setSceneDescription(e.target.value)}
                    placeholder="e.g., In a dimly lit bar in the lower levels of ŁĪƝĈ, rain streaking down the grimy window panes."
                    rows={2}
                    disabled={isGenerating}
                    className="bg-slate-700 border border-slate-600 text-slate-300 text-sm rounded-lg focus:ring-indigo-500 focus:border-indigo-500 block w-full p-2.5 disabled:opacity-50"
                />
            </div>

             <div className="mb-4 flex items-center">
                <input
                    type="checkbox"
                    id="thinking-mode-dialogue"
                    checked={useThinkingMode}
                    onChange={(e) => setUseThinkingMode(e.target.checked)}
                    disabled={isGenerating}
                    className="w-4 h-4 text-indigo-600 bg-slate-700 border-slate-600 rounded focus:ring-indigo-500"
                />
                <label htmlFor="thinking-mode-dialogue" className="ml-2 text-sm font-medium text-slate-400">
                    Enable Enhanced Character Depth (Slower)
                </label>
            </div>

            {isGenerating ? (
                 <button onClick={handleStopGeneration} className="bg-red-600 text-white font-bold py-2 px-6 rounded-lg hover:bg-red-500 transition-all duration-300">
                    Stop Scene
                </button>
            ) : (
                <button onClick={handleStartGeneration} disabled={isGenerating} className="bg-indigo-600 text-white font-bold py-2 px-6 rounded-lg hover:bg-indigo-500 disabled:bg-slate-600 transition-all duration-300">
                    Start Scene
                </button>
            )}

            {error && (
                 <div className="mt-4 w-full bg-red-900/50 border border-red-700 text-red-300 px-4 py-3 rounded-lg text-center">
                    <p><strong>Error:</strong> {error}</p>
                 </div>
            )}
            
            <div className="mt-6 w-full bg-slate-900/50 border border-slate-700 p-4 rounded-lg min-h-[200px]">
                <h3 className="text-lg font-semibold text-cyan-400 mb-2 font-mono">LIVE SCRIPT</h3>
                <div className="space-y-3 text-sm font-mono">
                    {dialogue.length > 0 ? (
                        dialogue.map((entry, index) => {
                             const isSpeaking = speakingCharacter === entry.speaker && index === dialogue.length - 1;
                             return (
                                <div key={index} className={`border-l-4 py-1 pl-3 transition-all duration-300 ${isSpeaking ? 'bg-slate-800' : ''} ${entry.speaker === charA ? 'border-indigo-500' : 'border-cyan-500'}`}>
                                    <span className={`font-bold ${entry.speaker === charA ? 'text-indigo-400' : 'text-cyan-400'}`}>{entry.speaker}: </span>
                                    <span className="text-slate-300 whitespace-pre-wrap">{entry.text}</span>
                                    {isSpeaking && <span className="ml-2 text-xs text-slate-500 animate-pulse">speaking...</span>}
                                </div>
                            )
                        })
                    ) : (
                         <p className="text-slate-500 italic">{isGenerating ? 'Generating first line...' : 'Awaiting scene generation...'}</p>
                    )}
                </div>
            </div>
        </div>
    );
};
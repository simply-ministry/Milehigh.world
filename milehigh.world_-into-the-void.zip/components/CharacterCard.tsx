import React, { useState, useCallback } from 'react';
import type { Character } from '../types';
import { generateCharacterMission, queryLore } from '../services/geminiService';

interface CharacterCardProps {
  character: Character;
  index: number;
  loreContext: string;
}

export const CharacterCard: React.FC<CharacterCardProps> = ({ character, index, loreContext }) => {
  const [generatedContent, setGeneratedContent] = useState<{type: 'mission' | 'lore', title: string, text: string} | null>(null);
  const [isLoading, setIsLoading] = useState<string | null>(null); // Can be 'mission', 'lore', or null
  const [error, setError] = useState<string | null>(null);

  const handleGenerateMission = useCallback(async () => {
    if (isLoading) return;
    setIsLoading('mission');
    setError(null);
    setGeneratedContent(null);
    try {
        const missionText = await generateCharacterMission(loreContext, character.name, character.description);
        setGeneratedContent({ 
            type: 'mission', 
            title: `Mission Briefing: ${character.name}`,
            text: missionText 
        });
    } catch (err) {
        setError(err instanceof Error ? err.message : 'An unknown error occurred.');
    } finally {
        setIsLoading(null);
    }
  }, [loreContext, character, isLoading]);

  const handleLoreDeepDive = useCallback(async () => {
      if (isLoading) return;
      setIsLoading('lore');
      setError(null);
      setGeneratedContent(null);
      try {
          const loreText = await queryLore(
              loreContext, 
              `Provide a detailed deep dive into the background, personality, and motivations of ${character.name}. Focus on information that isn't explicitly stated in their short bio. Critically, include a dedicated section speculating on their potential secrets or hidden fears, drawing nuanced inferences from the lore.`,
              true // Use thinking mode for a deeper answer
          );
          setGeneratedContent({ 
              type: 'lore', 
              title: `Lore Deep Dive: ${character.name}`,
              text: loreText 
          });
      } catch (err) {
          setError(err instanceof Error ? err.message : 'An unknown error occurred.');
      } finally {
          setIsLoading(null);
      }
  }, [loreContext, character, isLoading]);

  const clearGeneratedContent = () => {
      setGeneratedContent(null);
      setError(null);
  };

  return (
    <div
      className="bg-slate-800/50 border border-slate-700 rounded-lg overflow-hidden flex flex-col h-full transition-all duration-300 hover:scale-105 hover:border-indigo-500 hover:shadow-lg hover:shadow-indigo-500/20 opacity-0 animate-fade-in-up"
      style={{ animationDelay: `${index * 100}ms` }}
    >
      <img src={character.imageUrl} alt={character.name} className="w-full h-48 object-cover" />
      <div className="p-4 flex flex-col flex-grow">
        <h3 className="text-lg font-bold text-cyan-400">{character.name}</h3>
        <p className="text-sm text-indigo-400 mb-2">{character.title}</p>
        <p className="text-slate-400 text-sm mb-4 flex-grow">{character.description}</p>
        <div className="mb-4">
          <h4 className="text-xs text-slate-500 mb-1 font-mono">USD Snippet:</h4>
          <pre className="bg-slate-900 text-slate-300 text-xs p-3 rounded-md overflow-x-auto whitespace-pre-wrap font-mono">
            <code>{character.usd}</code>
          </pre>
        </div>

        <div className="mt-auto pt-4 border-t border-slate-600">
          <div className="flex gap-2 justify-center">
            <button 
              onClick={handleGenerateMission} 
              disabled={!!isLoading}
              className="flex-1 text-xs font-bold bg-slate-700 text-slate-300 px-3 py-2 rounded-md hover:bg-slate-600 hover:text-white transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isLoading === 'mission' ? 'Generating...' : 'Generate Mission'}
            </button>
            <button 
              onClick={handleLoreDeepDive} 
              disabled={!!isLoading}
              className="flex-1 text-xs font-bold bg-slate-700 text-slate-300 px-3 py-2 rounded-md hover:bg-slate-600 hover:text-white transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
               {isLoading === 'lore' ? 'Analyzing...' : 'Lore Deep Dive'}
            </button>
          </div>
          
          {error && (
            <div className="mt-4 w-full bg-red-900/50 border border-red-700 text-red-300 px-3 py-2 rounded-lg text-center text-sm">
                <p><strong>Error:</strong> {error}</p>
            </div>
          )}

          {generatedContent && (
            <div className="mt-4 p-3 bg-slate-900/70 rounded-md border border-slate-700 animate-fade-in">
                <div className="flex justify-between items-center mb-2">
                    <h4 className="text-sm font-bold text-cyan-400 font-mono">{generatedContent.title}</h4>
                    <button 
                      onClick={clearGeneratedContent} 
                      className="text-slate-500 hover:text-slate-300 text-lg"
                      aria-label="Close"
                    >
                      &times;
                    </button>
                </div>
                <p className="text-sm text-slate-300 whitespace-pre-line font-mono">{generatedContent.text}</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
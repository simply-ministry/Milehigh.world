
import React, { useState, useCallback } from 'react';
import { sanitizeInput } from '../utils/textUtils';

interface IntelLoggerProps {
  addIntelToLog: (newIntel: string) => void;
}

export const IntelLogger: React.FC<IntelLoggerProps> = ({ addIntelToLog }) => {
    const [intel, setIntel] = useState('');
    const [submitted, setSubmitted] = useState(false);

    const handleSubmit = useCallback((e: React.FormEvent) => {
        e.preventDefault();
        const sanitizedIntel = sanitizeInput(intel);
        if (!sanitizedIntel) return;
        
        addIntelToLog(sanitizedIntel);
        setIntel('');
        setSubmitted(true);
        setTimeout(() => setSubmitted(false), 3000);
    }, [intel, addIntelToLog]);

    return (
        <div className="flex flex-col">
            <p className="text-slate-400 mb-4 text-center">Add newfound intel to Omega.one's memory log. This will update the context for all AI-powered components in real-time.</p>
            <form onSubmit={handleSubmit} className="flex flex-col gap-2">
                <textarea
                    value={intel}
                    onChange={(e) => setIntel(e.target.value)}
                    placeholder="e.g., Lucent has established a new base in the Glimmering Depths..."
                    rows={3}
                    className="flex-grow bg-slate-700 border border-slate-600 text-slate-300 text-sm rounded-lg focus:ring-indigo-500 focus:border-indigo-500 block w-full p-2.5"
                />
                <button
                    type="submit"
                    disabled={!intel.trim()}
                    className="bg-cyan-600 text-white font-bold py-2 px-6 rounded-lg hover:bg-cyan-500 disabled:bg-slate-600 disabled:cursor-not-allowed transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-cyan-400 focus:ring-opacity-75"
                >
                    Log New Intel
                </button>
            </form>
             {submitted && (
                <p className="text-sm text-cyan-400 mt-2 text-center transition-opacity duration-500 animate-pulse">
                    Intel successfully added to memory log.
                </p>
            )}
        </div>
    );
}

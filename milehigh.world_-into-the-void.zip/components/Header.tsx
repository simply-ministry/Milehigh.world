

import React from 'react';

export const Header: React.FC = () => {
    return (
        <header className="text-center py-4 border-b-2 border-indigo-500/30">
            <h1 className="text-4xl md:text-5xl font-bold text-cyan-400 tracking-wider" style={{ textShadow: '0 0 10px rgba(56, 189, 248, 0.5)' }}>
                MILEHIGH.WORLD
            </h1>
            <p className="text-indigo-400 mt-2 text-lg md:text-xl">Into the Void: Repository Explorer</p>
        </header>
    );
};
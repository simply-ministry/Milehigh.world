

import React, { useState, useCallback, useRef, useEffect } from 'react';
import { queryLore, generateSpeech } from '../services/geminiService';
import { sanitizeInput } from '../utils/textUtils';
import { decode, decodeAudioData } from '../utils/audio';
import { SpeakerIcon, StopIcon } from '../constants';
import type { VoiceProfile } from '../types';

interface LoreQueryProps {
  loreContext: string;
  voiceProfiles: VoiceProfile[];
}

export const LoreQuery: React.FC<LoreQueryProps> = ({ loreContext, voiceProfiles }) => {
    const [query, setQuery] = useState<string>('');
    const [lastQuery, setLastQuery] = useState<string>('');
    const [response, setResponse] = useState<string>('');
    const [isLoading, setIsLoading] = useState<boolean>(false);
    const [error, setError] = useState<string | null>(null);
    const [useThinkingMode, setUseThinkingMode] = useState<boolean>(false);
    const [isSpeaking, setIsSpeaking] = useState<boolean>(false);

    const audioContextRef = useRef<AudioContext | null>(null);
    const audioSourceRef = useRef<AudioBufferSourceNode | null>(null);

    const stopAudio = useCallback(() => {
        if (audioSourceRef.current) {
            audioSourceRef.current.stop();
            audioSourceRef.current.disconnect();
            audioSourceRef.current = null;
        }
        if (audioContextRef.current && audioContextRef.current.state !== 'closed') {
            audioContextRef.current.close().catch(console.error);
            audioContextRef.current = null;
        }
        setIsSpeaking(false);
    }, []);

    const handleListen = useCallback(async () => {
        if (isSpeaking) {
            stopAudio();
            return;
        }
        if (!response) return;

        setIsSpeaking(true);
        setError(null);

        try {
            const omegaOneProfile = voiceProfiles.find(p => p.characterName === 'Sky.ix');
            const base64Audio = await generateSpeech(response, 'Zephyr', {
              pitch: omegaOneProfile?.pitch,
              speakingRate: omegaOneProfile?.speakingRate,
            }); // 'Zephyr' for Omega.one

            if (!audioContextRef.current || audioContextRef.current.state === 'closed') {
                audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
            }
            const ctx = audioContextRef.current;
            const audioBuffer = await decodeAudioData(decode(base64Audio), ctx, 24000, 1);
            
            const source = ctx.createBufferSource();
            audioSourceRef.current = source;
            source.buffer = audioBuffer;
            source.connect(ctx.destination);
            source.onended = () => {
                 if (audioSourceRef.current === source) {
                    stopAudio();
                }
            };
            source.start();
        } catch (err) {
            setError(err instanceof Error ? `Audio generation failed: ${err.message}` : 'An unknown audio error occurred.');
            stopAudio();
        }
    }, [response, isSpeaking, stopAudio, voiceProfiles]);

    // Cleanup effect
    useEffect(() => {
        return () => {
            stopAudio();
        };
    }, [stopAudio]);

    const handleQuerySubmit = useCallback(async (e: React.FormEvent) => {
        e.preventDefault();
        stopAudio();
        const sanitizedQuery = sanitizeInput(query);
        if (!sanitizedQuery) return;

        setIsLoading(true);
        setError(null);
        setResponse('');
        setLastQuery(sanitizedQuery);

        try {
            const result = await queryLore(loreContext, sanitizedQuery, useThinkingMode);
            setResponse(result);
        } catch (err) {
            setError(err instanceof Error ? err.message : 'An unknown error occurred.');
        } finally {
            setIsLoading(false);
            setQuery('');
        }
    }, [query, loreContext, useThinkingMode, stopAudio]);

    return (
        <div className="flex flex-col">
            <p className="text-slate-400 mb-4 text-center">Query Omega.one's memory log for specific information about the Verse.</p>
            <form onSubmit={handleQuerySubmit} className="flex flex-col">
                <div className="flex flex-col sm:flex-row gap-2">
                    <input
                        type="text"
                        value={query}
                        onChange={(e) => setQuery(e.target.value)}
                        placeholder="e.g., What is the Onalym Nexus?"
                        disabled={isLoading}
                        className="flex-grow bg-slate-700 border border-slate-600 text-slate-300 text-sm rounded-lg focus:ring-indigo-500 focus:border-indigo-500 block w-full p-2.5 disabled:opacity-50"
                    />
                    <button
                        type="submit"
                        disabled={isLoading || !query.trim()}
                        className="bg-indigo-600 text-white font-bold py-2 px-6 rounded-lg hover:bg-indigo-500 disabled:bg-slate-600 disabled:cursor-not-allowed transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-indigo-400 focus:ring-opacity-75"
                    >
                        {isLoading ? 'Querying...' : 'Submit Query'}
                    </button>
                </div>
                 <div className="mt-2 flex items-center justify-center">
                    <input
                        type="checkbox"
                        id="thinking-mode-query"
                        checked={useThinkingMode}
                        onChange={(e) => setUseThinkingMode(e.target.checked)}
                        disabled={isLoading}
                        className="w-4 h-4 text-indigo-600 bg-slate-700 border-slate-600 rounded focus:ring-indigo-500"
                    />
                    <label htmlFor="thinking-mode-query" className="ml-2 text-sm font-medium text-slate-400">
                        Enable Deep Analysis (Slower, for complex queries)
                    </label>
                </div>
            </form>
            
            {error && (
                 <div className="mt-4 w-full bg-red-900/50 border border-red-700 text-red-300 px-4 py-3 rounded-lg text-center">
                    <p><strong>Error:</strong> {error}</p>
                 </div>
            )}
            
            {(response || isLoading || lastQuery) && (
                <div className="mt-6 w-full bg-slate-900/50 border border-slate-700 p-4 rounded-lg">
                    {lastQuery && (
                      <div className="mb-4">
                        <h3 className="text-sm font-semibold text-indigo-400 mb-1 font-mono">QUERY:</h3>
                        <p className="text-slate-400 font-mono text-sm">{lastQuery}</p>
                      </div>
                    )}
                    {(response || isLoading) && <div className="border-t border-slate-700 pt-4">
                       <div className="flex justify-between items-center mb-1">
                            <h3 className="text-sm font-semibold text-cyan-400 font-mono">OMEGA.ONE RESPONSE:</h3>
                            {response && !isLoading && (
                                <button
                                    onClick={handleListen}
                                    disabled={isLoading}
                                    className="flex items-center text-sm bg-slate-700 hover:bg-slate-600 px-2 py-1 rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                                    aria-label={isSpeaking ? "Stop playback" : "Listen to response"}
                                >
                                    {isSpeaking ? (
                                        <>
                                            <StopIcon className="mr-1 h-4 w-4" /> Stop
                                        </>
                                    ) : (
                                        <>
                                            <SpeakerIcon className="mr-1 h-4 w-4" /> Listen
                                        </>
                                    )}
                                </button>
                            )}
                        </div>
                        {isLoading ? (
                            <div className="flex items-center text-slate-500">
                                <svg className="animate-spin mr-2 h-4 w-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                                </svg>
                                Accessing memory log...
                            </div>
                        ) : (
                            <p className="text-slate-300 whitespace-pre-line font-mono text-sm">{response}</p>
                        )}
                    </div>}
                </div>
            )}
        </div>
    );
};
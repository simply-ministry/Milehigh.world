import React from 'react';
import type { Reputation } from '../types';

interface ReputationTrackerProps {
  reputation: Reputation;
}

export const ReputationTracker: React.FC<ReputationTrackerProps> = ({ reputation }) => {
  const getBarColor = (score: number) => {
    if (score < 25) return 'bg-red-500';
    if (score < 50) return 'bg-yellow-500';
    if (score < 75) return 'bg-cyan-500';
    return 'bg-green-500';
  };

  return (
    <div className="space-y-4">
      {Object.entries(reputation).map(([faction, scoreValue]) => {
        // Fix: Cast score value to number as Object.entries can return `unknown` for values, causing a type error.
        const score = scoreValue as number;
        return (
          <div key={faction}>
            <div className="flex justify-between items-baseline mb-1">
              <span className="text-sm font-medium text-slate-300">{faction}</span>
              <span className="text-sm font-bold text-cyan-400 font-mono">{score} / 100</span>
            </div>
            <div className="w-full bg-slate-700 rounded-full h-2.5">
              <div
                className={`h-2.5 rounded-full transition-all duration-500 ${getBarColor(score)}`}
                style={{ width: `${score}%` }}
              ></div>
            </div>
          </div>
        );
      })}
    </div>
  );
};

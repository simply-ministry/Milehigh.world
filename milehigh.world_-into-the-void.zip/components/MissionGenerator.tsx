import React, { useState, useCallback, useRef, useEffect } from 'react';
import { generateMissionPrompt, generateSpeech } from '../services/geminiService';
import type { MissionGenerationResponse, VoiceProfile } from '../types';
import { decode, decodeAudioData } from '../utils/audio';
import { SpeakerIcon, StopIcon } from '../constants';

interface MissionGeneratorProps {
  loreContext: string;
  addIntelToLog: (intel: string) => void;
  updateReputation: (faction: string, change: number) => void;
  voiceProfiles: VoiceProfile[];
}

export const MissionGenerator: React.FC<MissionGeneratorProps> = ({ loreContext, addIntelToLog, updateReputation, voiceProfiles }) => {
    const [mission, setMission] = useState<MissionGenerationResponse | null>(null);
    const [isLoading, setIsLoading] = useState<boolean>(false);
    const [error, setError] = useState<string | null>(null);
    const [useThinkingMode, setUseThinkingMode] = useState<boolean>(false);
    const [isSpeaking, setIsSpeaking] = useState<boolean>(false);

    const audioContextRef = useRef<AudioContext | null>(null);
    const audioSourceRef = useRef<AudioBufferSourceNode | null>(null);

    const stopAudio = useCallback(() => {
        if (audioSourceRef.current) {
            audioSourceRef.current.stop();
            audioSourceRef.current.disconnect();
            audioSourceRef.current = null;
        }
        if (audioContextRef.current && audioContextRef.current.state !== 'closed') {
            audioContextRef.current.close().catch(console.error);
            audioContextRef.current = null;
        }
        setIsSpeaking(false);
    }, []);

    const handleListenToBriefing = useCallback(async () => {
        if (isSpeaking) {
            stopAudio();
            return;
        }
        if (!mission?.mission) return;

        setIsSpeaking(true);
        // Clear previous errors when attempting a new action
        setError(null);

        try {
            const omegaOneProfile = voiceProfiles.find(p => p.characterName === 'Sky.ix'); // Omega.one uses Sky.ix's voice config
            const base64Audio = await generateSpeech(mission.mission, 'Zephyr', { 
              pitch: omegaOneProfile?.pitch, 
              speakingRate: omegaOneProfile?.speakingRate 
            });

            if (!audioContextRef.current || audioContextRef.current.state === 'closed') {
                audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
            }
            const ctx = audioContextRef.current;
            const audioBuffer = await decodeAudioData(decode(base64Audio), ctx, 24000, 1);

            const source = ctx.createBufferSource();
            audioSourceRef.current = source;
            source.buffer = audioBuffer;
            source.connect(ctx.destination);
            source.onended = () => {
                if (audioSourceRef.current === source) {
                    stopAudio();
                }
            };
            source.start();
        } catch (err) {
            setError(err instanceof Error ? `Audio failed: ${err.message}` : 'An unknown audio error occurred.');
            stopAudio();
        }
    }, [mission, isSpeaking, stopAudio, voiceProfiles]);
    
    // Effect for cleaning up audio on component unmount
    useEffect(() => {
        return () => {
            stopAudio();
        };
    }, [stopAudio]);

    // Effect for stopping audio when the mission is acknowledged or declined
    useEffect(() => {
        if (!mission) {
            stopAudio();
        }
    }, [mission, stopAudio]);


    const handleGenerateMission = useCallback(async () => {
        setIsLoading(true);
        setError(null);
        setMission(null);
        try {
            const resultJson = await generateMissionPrompt(loreContext, useThinkingMode);
            const parsedResult: MissionGenerationResponse = JSON.parse(resultJson);
            setMission(parsedResult);
        } catch (err) {
            setError(err instanceof Error ? `Failed to generate or parse mission. ${err.message}` : 'An unknown error occurred.');
        } finally {
            setIsLoading(false);
        }
    }, [loreContext, useThinkingMode]);

    const handleAcknowledgeMission = useCallback(() => {
        if (!mission) return;

        const intelLog = `Mission Acknowledged:\n- **Objective:** ${mission.objective}\n- **Assessed Risks:** ${mission.consequences}`;
        addIntelToLog(intelLog);

        mission.reputationImpact.forEach(impact => {
            updateReputation(impact.faction, impact.change);
        });
        
        setMission(null);
    }, [mission, addIntelToLog, updateReputation]);

    const getReputationChangeColor = (change: number) => {
        if (change > 0) return 'text-green-400';
        if (change < 0) return 'text-red-400';
        return 'text-slate-400';
    };

    return (
        <div className="flex flex-col items-center">
            {!mission && (
                <>
                    <p className="text-slate-400 mb-4 text-center">Generate a unique mission with reputation consequences for the Ɲōvəmîŋāđ.</p>
                    <button
                        onClick={handleGenerateMission}
                        disabled={isLoading}
                        className="bg-indigo-600 text-white font-bold py-2 px-6 rounded-lg hover:bg-indigo-500 disabled:bg-slate-600 disabled:cursor-not-allowed transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-indigo-400 focus:ring-opacity-75"
                    >
                        {isLoading ? 'Generating...' : 'Generate Mission'}
                    </button>
                    <div className="mt-2 flex items-center">
                        <input
                            type="checkbox"
                            id="thinking-mode-mission"
                            checked={useThinkingMode}
                            onChange={(e) => setUseThinkingMode(e.target.checked)}
                            disabled={isLoading}
                            className="w-4 h-4 text-indigo-600 bg-slate-700 border-slate-600 rounded focus:ring-indigo-500"
                        />
                        <label htmlFor="thinking-mode-mission" className="ml-2 text-sm font-medium text-slate-400">
                            Enable Deep Mission Planning (Slower)
                        </label>
                    </div>
                </>
            )}
            
            {error && (
                 <div className="mt-4 w-full bg-red-900/50 border border-red-700 text-red-300 px-4 py-3 rounded-lg text-center">
                    <p><strong>Error:</strong> {error}</p>
                 </div>
            )}
            
            {mission && !isLoading && (
                <div className="mt-6 w-full bg-slate-900/50 border border-slate-700 p-4 rounded-lg animate-fade-in-up">
                    <div className="flex justify-between items-center mb-2">
                        <h3 className="text-lg font-semibold text-cyan-400 font-mono">CLASSIFIED MISSION BRIEFING</h3>
                        <button
                            onClick={handleListenToBriefing}
                            disabled={isLoading}
                            className="flex items-center text-sm bg-slate-700 hover:bg-slate-600 px-2 py-1 rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                            aria-label={isSpeaking ? "Stop briefing playback" : "Listen to briefing"}
                        >
                             {isSpeaking ? (
                                <>
                                    <StopIcon className="mr-1 h-4 w-4" /> Stop
                                </>
                            ) : (
                                <>
                                    <SpeakerIcon className="mr-1 h-4 w-4" /> Listen
                                </>
                            )}
                        </button>
                    </div>

                    <p className="text-slate-300 whitespace-pre-line font-mono text-sm">{mission.mission}</p>

                    <div className="mt-4 border-t border-slate-700 pt-4">
                        <h4 className="text-md font-semibold text-cyan-400 mb-2 font-mono">Primary Objective</h4>
                        <p className="text-sm font-mono text-slate-300">{mission.objective}</p>
                    </div>
                    
                    <div className="mt-4 border-t border-slate-700 pt-4">
                        <h4 className="text-md font-semibold text-indigo-400 mb-2 font-mono">Reputation Impact</h4>
                        <ul className="text-sm font-mono">
                            {mission.reputationImpact.map((impact, index) => (
                                <li key={index}>
                                    - {impact.faction}: <span className={getReputationChangeColor(impact.change)}>{impact.change > 0 ? '+' : ''}{impact.change}</span>
                                </li>
                            ))}
                        </ul>
                    </div>
                    
                    <div className="mt-4 border-t border-slate-700 pt-4">
                        <h4 className="text-md font-semibold text-red-400 mb-2 font-mono">Potential Risks & Consequences</h4>
                        <p className="text-sm font-mono text-slate-400">{mission.consequences}</p>
                    </div>

                    <div className="mt-6 flex justify-end gap-4">
                         <button onClick={() => setMission(null)} className="bg-slate-600 text-white font-bold py-2 px-4 rounded-lg hover:bg-slate-500 transition-all duration-300">
                           Decline
                         </button>
                         <button onClick={handleAcknowledgeMission} className="bg-cyan-600 text-white font-bold py-2 px-4 rounded-lg hover:bg-cyan-500 transition-all duration-300">
                           Acknowledge & Proceed
                         </button>
                    </div>
                </div>
            )}
        </div>
    );
};